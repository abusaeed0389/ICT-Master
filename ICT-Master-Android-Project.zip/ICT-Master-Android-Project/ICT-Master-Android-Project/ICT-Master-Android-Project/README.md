# ICT Master 2.0 (Android, Kotlin + Jetpack Compose + Material 3)

Offline HSC ICT companion app. Developed by Abu Saeed - https://isaeed.netlify.app

## Build
- JDK 17, Gradle 8.7 (wrapper included), Android Gradle Plugin 8.5.2, compileSdk 34, minSdk 28 (Android 9)
- `./gradlew assembleDebug`  ->  `app/build/outputs/apk/debug/app-debug.apk`
- A ready GitHub Actions workflow is in `.github/workflows/build.yml`.

## Structure
- `logic/`  pure Kotlin engines (number systems, binary ops, gates, Boolean algebra) - no Android dependency
- `data/`   tool registry, question bank, SharedPreferences-backed app state (settings, history, quiz progress)
- `ui/`     Compose screens and components
