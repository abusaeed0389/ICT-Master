package com.abusaeed.ictmaster.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

class HistoryItem(
    val id: Long,
    val toolId: String,
    val label: String,
    val input: String,
    val output: String,
    val ts: Long,
    val p1: Int = 0,
    val p2: Int = 0
)

class SessionRecord(val ts: Long, val topic: String, val difficulty: Int, val total: Int, val correct: Int)

/** Single source of truth for user settings and locally stored data (SharedPreferences, no database needed). */
class AppState(context: Context) {
    private val prefs: SharedPreferences = context.applicationContext.getSharedPreferences("ict_master", Context.MODE_PRIVATE)

    // ----- settings -----
    private val themeState = mutableIntStateOf(prefs.getInt("theme", 0))
    var theme: Int
        get() = themeState.intValue
        set(v) { themeState.intValue = v; prefs.edit().putInt("theme", v).apply() }   // 0 system, 1 light, 2 dark

    private val langState = mutableStateOf(prefs.getString("lang", "bn") ?: "bn")
    var lang: String
        get() = langState.value
        set(v) { langState.value = v; prefs.edit().putString("lang", v).apply() }
    val isBangla: Boolean get() = lang == "bn"

    private val hapticState = mutableStateOf(prefs.getBoolean("haptic", true))
    var haptic: Boolean
        get() = hapticState.value
        set(v) { hapticState.value = v; prefs.edit().putBoolean("haptic", v).apply() }

    private val nameState = mutableStateOf(prefs.getString("user_name", "") ?: "")
    var userName: String
        get() = nameState.value
        set(v) { nameState.value = v.trim().take(30); prefs.edit().putString("user_name", nameState.value).apply() }

    /** Category filter requested by Home ("FAV", a Category name, or null for all). */
    var toolsFilter by mutableStateOf<String?>(null)

    // ----- favourites / recents / searches -----
    val favorites = mutableStateListOf<String>().apply { addAll(readList("favorites")) }
    val recentTools = mutableStateListOf<String>().apply { addAll(readList("recent_tools")) }
    val recentSearches = mutableStateListOf<String>().apply { addAll(readList("recent_searches")) }

    private fun readList(key: String): List<String> =
        (prefs.getString(key, "") ?: "").split("\u001F").filter { it.isNotEmpty() }

    private fun writeList(key: String, list: List<String>) {
        prefs.edit().putString(key, list.joinToString("\u001F")).apply()
    }

    fun toggleFavorite(id: String) {
        if (favorites.contains(id)) favorites.remove(id) else favorites.add(id)
        writeList("favorites", favorites)
    }

    fun markToolUsed(id: String) {
        recentTools.remove(id); recentTools.add(0, id)
        while (recentTools.size > 6) recentTools.removeAt(recentTools.lastIndex)
        writeList("recent_tools", recentTools)
        val c = prefs.getInt("use_$id", 0) + 1
        prefs.edit().putInt("use_$id", c).apply()
    }

    fun useCount(id: String) = prefs.getInt("use_$id", 0)

    fun addSearch(q: String) {
        val s = q.trim()
        if (s.length < 2) return
        recentSearches.remove(s); recentSearches.add(0, s)
        while (recentSearches.size > 8) recentSearches.removeAt(recentSearches.lastIndex)
        writeList("recent_searches", recentSearches)
    }

    fun clearSearches() { recentSearches.clear(); writeList("recent_searches", recentSearches) }

    // ----- history -----
    val history = mutableStateListOf<HistoryItem>().apply { addAll(loadHistory()) }

    /** Converter "open previous result" hand-over: (fromBase, toBase, input). */
    var pendingConversion: Triple<Int, Int, String>? = null
    /** Other tools' "open previous result" hand-over: (input, p1, p2). */
    var pendingToolInput: Triple<String, Int, Int>? = null

    private fun loadHistory(): List<HistoryItem> {
        val out = mutableListOf<HistoryItem>()
        try {
            val arr = JSONArray(prefs.getString("history", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += HistoryItem(o.getLong("id"), o.getString("tool"), o.getString("label"), o.getString("in"), o.getString("out"),
                    o.getLong("ts"), o.optInt("p1"), o.optInt("p2"))
            }
        } catch (e: Exception) { /* corrupted data: start fresh */ }
        return out
    }

    private fun saveHistory() {
        val arr = JSONArray()
        for (h in history) arr.put(JSONObject().put("id", h.id).put("tool", h.toolId).put("label", h.label)
            .put("in", h.input).put("out", h.output).put("ts", h.ts).put("p1", h.p1).put("p2", h.p2))
        prefs.edit().putString("history", arr.toString()).apply()
    }

    fun addHistory(toolId: String, label: String, input: String, output: String, p1: Int = 0, p2: Int = 0) {
        val first = history.firstOrNull()
        if (first != null && first.toolId == toolId && first.label == label && first.input == input && first.output == output) return
        history.add(0, HistoryItem(System.currentTimeMillis(), toolId, label, input.take(300), output.take(600), System.currentTimeMillis(), p1, p2))
        while (history.size > 300) history.removeAt(history.lastIndex)
        saveHistory()
    }

    fun deleteHistory(id: Long) { history.removeAll { it.id == id }; saveHistory() }
    fun clearHistory() { history.clear(); saveHistory() }

    // ----- quiz progress -----
    var quizTotal by mutableIntStateOf(prefs.getInt("quiz_total", 0)); private set
    var quizCorrect by mutableIntStateOf(prefs.getInt("quiz_correct", 0)); private set
    val wrongIds = mutableStateListOf<Int>().apply { addAll(readList("wrong_ids").mapNotNull { it.toIntOrNull() }) }
    val sessions = mutableStateListOf<SessionRecord>().apply { addAll(loadSessions()) }

    fun recordAnswer(questionId: Int, correct: Boolean) {
        quizTotal++; if (correct) quizCorrect++
        if (correct) wrongIds.remove(questionId) else if (!wrongIds.contains(questionId)) wrongIds.add(questionId)
        prefs.edit().putInt("quiz_total", quizTotal).putInt("quiz_correct", quizCorrect).apply()
        writeList("wrong_ids", wrongIds.map { it.toString() })
    }

    private fun loadSessions(): List<SessionRecord> {
        val out = mutableListOf<SessionRecord>()
        try {
            val arr = JSONArray(prefs.getString("sessions", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += SessionRecord(o.getLong("ts"), o.getString("topic"), o.getInt("diff"), o.getInt("total"), o.getInt("correct"))
            }
        } catch (e: Exception) { }
        return out
    }

    fun addSession(topic: String, difficulty: Int, total: Int, correct: Int) {
        sessions.add(0, SessionRecord(System.currentTimeMillis(), topic, difficulty, total, correct))
        while (sessions.size > 50) sessions.removeAt(sessions.lastIndex)
        val arr = JSONArray()
        for (s in sessions) arr.put(JSONObject().put("ts", s.ts).put("topic", s.topic).put("diff", s.difficulty).put("total", s.total).put("correct", s.correct))
        prefs.edit().putString("sessions", arr.toString()).apply()
    }

    fun clearQuizProgress() {
        quizTotal = 0; quizCorrect = 0; wrongIds.clear(); sessions.clear()
        prefs.edit().putInt("quiz_total", 0).putInt("quiz_correct", 0).remove("wrong_ids").remove("sessions").apply()
    }

    // ----- daily tip -----
    fun tipOfDay(): Pair<String, String> {
        val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        return TIPS[day % TIPS.size]
    }

    companion object {
        val TIPS = listOf(
            "বাইনারি থেকে অক্টালে যেতে ডান দিক থেকে ৩ বিট এবং হেক্সাডেসিমালে যেতে ৪ বিট করে ভাগ করুন।" to "To go from binary to octal group bits in 3s from the right; for hexadecimal use groups of 4.",
            "2's কমপ্লিমেন্ট = 1's কমপ্লিমেন্ট + 1। বিয়োগ করতে এটি খুব কাজে লাগে।" to "2's complement = 1's complement + 1. It makes subtraction easy.",
            "NAND ও NOR হলো সার্বজনীন গেট; এদের দিয়ে যেকোনো ডিজিটাল সার্কিট বানানো যায়।" to "NAND and NOR are universal gates; any digital circuit can be built from them.",
            "ডি মরগান: (A+B)′ = A′·B′ এবং (A·B)′ = A′+B′। যোগ গুণ হয়, গুণ যোগ হয়, আর পুরো অংশে বার বসে।" to "De Morgan: (A+B)′ = A′·B′ and (A·B)′ = A′+B′. Swap the operator and invert the terms.",
            "ASCII-তে 'A' = 65, 'a' = 97, '0' = 48। বড় ও ছোট হাতের অক্ষরের পার্থক্য সবসময় 32।" to "ASCII: 'A' = 65, 'a' = 97, '0' = 48. Upper and lower case differ by exactly 32.",
            "XOR গেট বলে দেয় দুটি বিট ভিন্ন কি না। বাইনারি যোগের সাম বিট এবং গ্রে কোডে এটি ব্যবহার হয়।" to "XOR tells whether two bits differ. It gives the sum bit in binary addition and is used in Gray code.",
            "BCD-তে প্রতিটি ডেসিমাল অঙ্ক আলাদা করে ৪ বিটে লেখা হয়: 29 → 0010 1001।" to "In BCD every decimal digit is written separately in 4 bits: 29 → 0010 1001.",
            "ভগ্নাংশ ডেসিমাল থেকে বাইনারিতে নিতে বারবার 2 দিয়ে গুণ করে পূর্ণ অংশ লিখুন।" to "To convert a decimal fraction to binary, multiply by 2 repeatedly and note the integer parts.",
            "n টি ইনপুটের সত্যক সারণিতে 2ⁿ টি সারি থাকে।" to "A truth table with n inputs has 2ⁿ rows.",
            "১ বাইট = ৮ বিট, ১ KB = ১০২৪ বাইট, ১ MB = ১০২৪ KB।" to "1 byte = 8 bits, 1 KB = 1024 bytes, 1 MB = 1024 KB."
        )
    }
}
