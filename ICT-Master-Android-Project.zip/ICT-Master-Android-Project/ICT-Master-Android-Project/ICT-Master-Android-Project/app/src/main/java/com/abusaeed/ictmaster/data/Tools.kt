package com.abusaeed.ictmaster.data

enum class Category(val bn: String, val en: String, val glyph: String) {
    NUMBER("সংখ্যা পদ্ধতি", "Number Systems", "01"),
    LOGIC("লজিক ও বুলিয়ান", "Logic & Boolean", "&"),
    CODES("ডিজিটাল কোড", "Digital Codes", "Aa"),
    OTHER("অন্যান্য টুলস", "Other Tools", "</>")
}

data class ToolDef(
    val id: String,
    val bn: String,
    val en: String,
    val cat: Category,
    val glyph: String,
    val descBn: String,
    val descEn: String,
    val keywords: String = ""
)

object Tools {
    const val CONVERTER = "converter"

    val all: List<ToolDef> = listOf(
        ToolDef(CONVERTER, "সংখ্যা পদ্ধতি রূপান্তর", "Number System Converter", Category.NUMBER, "⇄",
            "বাইনারি, অক্টাল, ডেসিমাল ও হেক্সাডেসিমাল রূপান্তর ধাপে ধাপে", "Binary, octal, decimal and hex conversion with steps",
            "binary decimal octal hexadecimal convert base বাইনারি ডেসিমাল অক্টাল হেক্সা রূপান্তর"),
        ToolDef("bin_add", "বাইনারি যোগ", "Binary Addition", Category.NUMBER, "+", "দুটি বাইনারি সংখ্যা যোগ ও ক্যারি", "Add two binary numbers with carries", "add sum যোগ"),
        ToolDef("bin_sub", "বাইনারি বিয়োগ", "Binary Subtraction", Category.NUMBER, "−", "2's কমপ্লিমেন্ট পদ্ধতিতে বিয়োগ", "Subtract using 2's complement", "subtract minus বিয়োগ"),
        ToolDef("bin_mul", "বাইনারি গুণ", "Binary Multiplication", Category.NUMBER, "×", "আংশিক গুণফলসহ বাইনারি গুণ", "Binary multiplication with partial products", "multiply product গুণ"),
        ToolDef("bin_div", "বাইনারি ভাগ", "Binary Division", Category.NUMBER, "÷", "ভাগফল ও ভাগশেষসহ বাইনারি ভাগ", "Binary division with quotient and remainder", "divide ভাগ"),
        ToolDef("ones", "1's কমপ্লিমেন্ট", "1's Complement", Category.NUMBER, "1′", "প্রতিটি বিট উল্টে দেওয়া", "Invert every bit", "ones complement এক কমপ্লিমেন্ট"),
        ToolDef("twos", "2's কমপ্লিমেন্ট", "2's Complement", Category.NUMBER, "2′", "1's কমপ্লিমেন্ট + 1", "1's complement plus 1", "twos complement দুই কমপ্লিমেন্ট negative"),
        ToolDef("bitwise", "বিটওয়াইজ AND, OR, XOR, NOT", "Bitwise AND, OR, XOR, NOT", Category.NUMBER, "&", "বিট স্তরে লজিক অপারেশন", "Logic operations on bits", "and or xor not bit"),
        ToolDef("bin2bcd", "বাইনারি → BCD", "Binary to BCD", Category.NUMBER, "BCD", "বাইনারি থেকে 8421 BCD কোড", "Binary to 8421 BCD code", "bcd binary coded decimal"),
        ToolDef("bcd2bin", "BCD → বাইনারি", "BCD to Binary", Category.NUMBER, "BCD", "BCD কোড থেকে বাইনারি", "BCD code to binary", "bcd binary coded decimal"),
        ToolDef("gates", "লজিক গেট সিমুলেটর", "Logic Gate Simulator", Category.LOGIC, "AND", "ইন্টারেক্টিভ গেট, সত্যক সারণি ও প্রতীক", "Interactive gates, truth tables and symbols", "and or not nand nor xor xnor gate truth table সত্যক সারণি"),
        ToolDef("boolean", "বুলিয়ান অ্যালজেবরা", "Boolean Algebra", Category.LOGIC, "ƒ", "এক্সপ্রেশন মূল্যায়ন, সত্যক সারণি ও সরলীকরণ", "Evaluate, truth table and simplify", "boolean expression simplify law de morgan সূত্র সরলীকরণ"),
        ToolDef("ascii", "ASCII কনভার্টার", "ASCII Converter", Category.CODES, "Aa", "অক্ষর ↔ ASCII কোড", "Text ↔ ASCII codes", "ascii unicode character code অক্ষর"),
        ToolDef("gray", "গ্রে কোড কনভার্টার", "Gray Code Converter", Category.CODES, "Gy", "বাইনারি ↔ গ্রে কোড", "Binary ↔ Gray code", "gray code grey গ্রে কোড"),
        ToolDef("hexcalc", "হেক্সাডেসিমাল ক্যালকুলেটর", "Hexadecimal Calculator", Category.OTHER, "0x", "হেক্সে যোগ, বিয়োগ, গুণ, ভাগ", "Hex add, subtract, multiply, divide", "hex calculator হেক্স ক্যালকুলেটর"),
        ToolDef("bincalc", "বাইনারি ক্যালকুলেটর", "Binary Calculator", Category.OTHER, "0b", "বাইনারিতে চার অপারেশন", "Four operations in binary", "binary calculator বাইনারি ক্যালকুলেটর"),
        ToolDef("units", "ইউনিট কনভার্টার", "Unit Converter", Category.OTHER, "KB", "বিট, বাইট, KB, MB, GB, TB, PB", "Bit, byte, KB, MB, GB, TB, PB", "unit byte kb mb gb tb storage মেমরি"),
        ToolDef("html", "HTML উদাহরণ ও প্রিভিউ", "HTML Examples & Preview", Category.OTHER, "</>", "বেসিক HTML কোড লিখে প্রিভিউ দেখুন", "Write basic HTML and preview it", "html web page ওয়েব"),
        ToolDef("cprog", "C প্রোগ্রামিং উদাহরণ", "C Programming Examples", Category.OTHER, "C", "বেসিক C কোড ও আউটপুট", "Basic C code with output", "c program programming প্রোগ্রামিং")
    )

    private val map = all.associateBy { it.id }
    fun byId(id: String): ToolDef? = map[id]

    /** Case-insensitive search over Bangla + English names and keywords. */
    fun search(q: String): List<ToolDef> {
        val s = q.trim().lowercase()
        if (s.isEmpty()) return emptyList()
        return all.filter {
            it.bn.lowercase().contains(s) || it.en.lowercase().contains(s) ||
                it.keywords.lowercase().contains(s) || it.descBn.contains(s) || it.descEn.lowercase().contains(s)
        }
    }

    val suggestions = listOf("binary", "hex", "2's complement", "truth table", "ASCII", "বাইনারি", "লজিক গেট", "বুলিয়ান")
}
