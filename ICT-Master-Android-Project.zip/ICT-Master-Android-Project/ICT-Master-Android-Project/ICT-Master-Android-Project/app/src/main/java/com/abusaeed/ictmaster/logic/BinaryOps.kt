package com.abusaeed.ictmaster.logic

import java.math.BigDecimal
import java.math.BigInteger
import java.math.RoundingMode

/** Binary arithmetic, complements, bitwise ops, BCD, Gray code, ASCII, units, base calculator. */
object BinaryOps {
    private const val MAX_BITS = 256

    private fun cleanBin(raw: String, bn: Boolean, label: String = ""): String {
        val s = raw.trim().replace(" ", "")
        val pre = if (label.isEmpty()) "" else "$label: "
        if (s.isEmpty()) throw IllegalArgumentException(pre + tx(bn, "একটি বাইনারি সংখ্যা লিখুন।", "Enter a binary number."))
        for (c in s) if (c != '0' && c != '1') throw IllegalArgumentException(
            pre + tx(bn, "'$c' বৈধ বাইনারি অঙ্ক নয়। শুধু 0 ও 1 ব্যবহার করুন।", "'$c' is not a binary digit. Use only 0 and 1.")
        )
        if (s.length > MAX_BITS) throw IllegalArgumentException(pre + tx(bn, "সর্বোচ্চ $MAX_BITS বিট ব্যবহার করুন।", "Use at most $MAX_BITS bits."))
        return s
    }

    private fun big(s: String) = BigInteger(s, 2)
    private fun bin(v: BigInteger) = v.toString(2)
    private fun pad(s: String, n: Int) = s.padStart(n, '0')

    private inline fun guard(block: () -> CalcResult): CalcResult =
        try { block() } catch (e: IllegalArgumentException) { CalcResult.fail(e.message ?: "") }

    // ---------------- Arithmetic ----------------
    fun add(a: String, b: String, bn: Boolean): CalcResult = guard {
        val x = cleanBin(a, bn, "A"); val y = cleanBin(b, bn, "B")
        val n = maxOf(x.length, y.length)
        val xa = pad(x, n); val ya = pad(y, n)
        val carries = CharArray(n + 1) { '0' }
        val sum = CharArray(n)
        var c = 0
        for (i in n - 1 downTo 0) {
            val t = (xa[i] - '0') + (ya[i] - '0') + c
            sum[i] = ('0' + (t % 2)); c = t / 2
            carries[i] = if (c == 1) '1' else '0'   // carry going into column i-1
        }
        val result = (if (c == 1) "1" else "") + String(sum)
        val steps = mutableListOf<String>()
        steps += tx(bn, "ডান দিক থেকে বিট যোগ করি: 0+0=0, 0+1=1, 1+1=10 (যোগফল 0, ক্যারি 1), 1+1+1=11 (যোগফল 1, ক্যারি 1)।",
            "Add bit by bit from the right: 0+0=0, 0+1=1, 1+1=10 (sum 0, carry 1), 1+1+1=11 (sum 1, carry 1).")
        val w = n + 1
        steps += "#Carry : " + String(carries.copyOfRange(0, n)).padEnd(w, ' ')
        steps += "#A     : " + xa.padStart(w, ' ')
        steps += "#B     : " + ya.padStart(w, ' ')
        steps += "#" + "-".repeat(8 + w)
        steps += "#Sum   : " + result.padStart(w, ' ')
        steps += tx(bn, "যাচাই: ${big(x)} + ${big(y)} = ${big(x).add(big(y))} (ডেসিমাল)", "Check: ${big(x)} + ${big(y)} = ${big(x).add(big(y))} (decimal)")
        CalcResult(true, bin(big(x).add(big(y))), steps = steps)
    }

    fun subtract(a: String, b: String, bn: Boolean): CalcResult = guard {
        val x = cleanBin(a, bn, "A"); val y = cleanBin(b, bn, "B")
        val n = maxOf(x.length, y.length)
        val bx = big(x); val by = big(y)
        val diff = bx.subtract(by)
        val steps = mutableListOf<String>()
        steps += tx(bn, "বিয়োগ করার জন্য 2's কমপ্লিমেন্ট পদ্ধতি ব্যবহার করি (A − B = A + B-এর 2's কমপ্লিমেন্ট)।",
            "Use the 2's complement method (A − B = A + 2's complement of B).")
        val mod = BigInteger.ONE.shiftLeft(n)
        val comp = mod.subtract(by).mod(mod)
        val compS = pad(bin(comp), n)
        steps += tx(bn, "ধাপ ১: $n বিটে B = ${pad(y, n)}-এর 2's কমপ্লিমেন্ট = $compS", "Step 1: in $n bits, 2's complement of B = ${pad(y, n)} is $compS")
        val total = bx.add(comp)
        val totalS = bin(total)
        steps += tx(bn, "ধাপ ২: A + 2's কমপ্লিমেন্ট = ${pad(x, n)} + $compS = $totalS", "Step 2: A + complement = ${pad(x, n)} + $compS = $totalS")
        if (bx >= by) {
            steps += tx(bn, "ধাপ ৩: ক্যারি (সর্বাধিক বাম বিট) আসায় তা বাদ দিই। ফলাফল ধনাত্মক।", "Step 3: a carry out occurred; discard it. The result is positive.")
            steps += tx(bn, "যাচাই: ${bx} − ${by} = $diff (ডেসিমাল)", "Check: $bx − $by = $diff (decimal)")
            CalcResult(true, bin(diff), steps = steps)
        } else {
            val mag = diff.negate()
            steps += tx(bn, "ধাপ ৩: কোনো ক্যারি আসেনি, অর্থাৎ ফলাফল ঋণাত্মক। ${totalS} হলো ফলাফলের 2's কমপ্লিমেন্ট; এর 2's কমপ্লিমেন্ট নিলে মান পাই ${bin(mag)}।",
                "Step 3: no carry out, so the result is negative. $totalS is the 2's complement of the answer; complementing again gives magnitude ${bin(mag)}.")
            steps += tx(bn, "যাচাই: ${bx} − ${by} = $diff (ডেসিমাল)", "Check: $bx − $by = $diff (decimal)")
            CalcResult(true, "-" + bin(mag), steps = steps, note = tx(bn, "ফলাফল ঋণাত্মক।", "The result is negative."))
        }
    }

    fun multiply(a: String, b: String, bn: Boolean): CalcResult = guard {
        val x = cleanBin(a, bn, "A"); val y = cleanBin(b, bn, "B")
        val prod = big(x).multiply(big(y))
        val res = bin(prod)
        val w = maxOf(res.length, x.length + y.length)
        val steps = mutableListOf<String>()
        steps += tx(bn, "গুণক (B)-এর প্রতিটি বিট ডান থেকে বাম দিকে নিয়ে আংশিক গুণফল তৈরি করি। বিট 1 হলে A লিখি, 0 হলে শূন্য; প্রতিবার এক ঘর বাঁয়ে সরাই।",
            "Take each bit of the multiplier (B) from right to left. For bit 1 write A, for 0 write zeros; shift one place left each time.")
        steps += "#" + x.padStart(w)
        steps += "#× " + y.padStart(w - 2)
        steps += "#" + "-".repeat(w)
        val partials = mutableListOf<BigInteger>()
        for ((i, ch) in y.reversed().withIndex()) {
            if (i >= 24) { steps += "#…"; break }
            val pp = if (ch == '1') x else "0".repeat(x.length)
            steps += "#" + (pp + "0".repeat(i)).padStart(w)
            partials += if (ch == '1') big(x).shiftLeft(i) else BigInteger.ZERO
        }
        steps += "#" + "-".repeat(w)
        steps += "#" + res.padStart(w)
        steps += tx(bn, "যাচাই: ${big(x)} × ${big(y)} = $prod (ডেসিমাল)", "Check: ${big(x)} × ${big(y)} = $prod (decimal)")
        CalcResult(true, res, steps = steps)
    }

    fun divide(a: String, b: String, bn: Boolean): CalcResult = guard {
        val x = cleanBin(a, bn, "A"); val y = cleanBin(b, bn, "B")
        if (big(y).signum() == 0) throw IllegalArgumentException(tx(bn, "শূন্য দিয়ে ভাগ করা যায় না।", "Division by zero is not possible."))
        val qr = big(x).divideAndRemainder(big(y))
        val steps = mutableListOf<String>()
        steps += tx(bn, "ভাজ্য A = $x (= ${big(x)}), ভাজক B = $y (= ${big(y)})", "Dividend A = $x (= ${big(x)}), divisor B = $y (= ${big(y)})")
        steps += tx(bn, "বাইনারি লং ডিভিশনে ভাজ্যের বিট বাম থেকে নিয়ে ভাজকের সাথে তুলনা করি; ভাজক ≤ বর্তমান অংশ হলে ভাগফলে 1, না হলে 0 বসে।",
            "In binary long division take dividend bits from the left; write 1 in the quotient when the divisor fits, otherwise 0.")
        // long division trace
        var rem = BigInteger.ZERO
        val qbits = StringBuilder()
        val by = big(y)
        for ((i, ch) in x.withIndex()) {
            rem = rem.shiftLeft(1).add(BigInteger.valueOf((ch - '0').toLong()))
            if (rem >= by) { qbits.append('1'); rem = rem.subtract(by) } else qbits.append('0')
            if (i < 20) steps += "#${tx(bn, "বিট", "bit")} $ch → ${tx(bn, "অবশিষ্ট", "remainder")} ${bin(rem)}, ${tx(bn, "ভাগফল বিট", "quotient bit")} ${qbits.last()}"
        }
        if (x.length > 20) steps += "#…"
        steps += tx(bn, "ভাগফল = ${bin(qr[0])}, ভাগশেষ = ${bin(qr[1])}", "Quotient = ${bin(qr[0])}, remainder = ${bin(qr[1])}")
        steps += tx(bn, "যাচাই: ${big(x)} ÷ ${big(y)} = ${qr[0]} ভাগশেষ ${qr[1]} (ডেসিমাল)", "Check: ${big(x)} ÷ ${big(y)} = ${qr[0]} remainder ${qr[1]} (decimal)")
        CalcResult(true, bin(qr[0]), steps = steps, note = tx(bn, "ভাগশেষ: ${bin(qr[1])}", "Remainder: ${bin(qr[1])}"))
    }

    // ---------------- Complements ----------------
    fun onesComplement(a: String, bn: Boolean): CalcResult = guard {
        val x = cleanBin(a, bn)
        val r = x.map { if (it == '0') '1' else '0' }.joinToString("")
        val steps = listOf(
            tx(bn, "1's কমপ্লিমেন্ট: প্রতিটি বিট উল্টে দিই (0 → 1, 1 → 0)।", "1's complement: invert every bit (0 → 1, 1 → 0)."),
            "#$x", "#↓", "#$r"
        )
        CalcResult(true, r, steps = steps)
    }

    fun twosComplement(a: String, bn: Boolean): CalcResult = guard {
        val x = cleanBin(a, bn)
        val ones = x.map { if (it == '0') '1' else '0' }.joinToString("")
        val n = x.length
        val mod = BigInteger.ONE.shiftLeft(n)
        val r = pad(bin(big(ones).add(BigInteger.ONE).mod(mod)), n)
        val steps = mutableListOf<String>()
        steps += tx(bn, "2's কমপ্লিমেন্ট = 1's কমপ্লিমেন্ট + 1", "2's complement = 1's complement + 1")
        steps += tx(bn, "ধাপ ১: 1's কমপ্লিমেন্ট: $x → $ones", "Step 1: 1's complement: $x → $ones")
        steps += tx(bn, "ধাপ ২: এর সাথে 1 যোগ: $ones + 1 = $r", "Step 2: add 1: $ones + 1 = $r")
        val note = if (big(x).signum() == 0)
            tx(bn, "সব বিট 0 হওয়ায় ওভারফ্লো ক্যারি বাদ গেছে; ফলাফল সব 0।", "All bits are 0, so the overflow carry is dropped; the result is all 0.")
        else ""
        CalcResult(true, r, steps = steps, note = note)
    }

    // ---------------- Bitwise ----------------
    fun bitwise(op: String, a: String, b: String, bn: Boolean): CalcResult = guard {
        val x = cleanBin(a, bn, if (op == "NOT") "" else "A")
        if (op == "NOT") {
            val r = x.map { if (it == '0') '1' else '0' }.joinToString("")
            return@guard CalcResult(true, r, steps = listOf(
                tx(bn, "NOT প্রতিটি বিটকে উল্টে দেয় (0 → 1, 1 → 0)।", "NOT inverts every bit (0 → 1, 1 → 0)."),
                "#A   : $x", "#NOT : $r"
            ))
        }
        val y = cleanBin(b, bn, "B")
        val n = maxOf(x.length, y.length)
        val xa = pad(x, n); val ya = pad(y, n)
        val sb = StringBuilder()
        for (i in 0 until n) {
            val p = xa[i] == '1'; val q = ya[i] == '1'
            val r = when (op) { "AND" -> p && q; "OR" -> p || q; else -> p != q }
            sb.append(if (r) '1' else '0')
        }
        val rule = when (op) {
            "AND" -> tx(bn, "AND: দুটি বিটই 1 হলে ফলাফল 1, নইলে 0।", "AND: result is 1 only if both bits are 1.")
            "OR" -> tx(bn, "OR: যেকোনো একটি বিট 1 হলে ফলাফল 1।", "OR: result is 1 if at least one bit is 1.")
            else -> tx(bn, "XOR: বিট দুটি ভিন্ন হলে ফলাফল 1, একই হলে 0।", "XOR: result is 1 when the bits differ, 0 when equal.")
        }
        val steps = listOf(
            rule,
            tx(bn, "দুটি সংখ্যার দৈর্ঘ্য সমান করতে বামে 0 বসানো হয়েছে।", "The shorter number is padded with leading zeros."),
            "#A      : $xa", "#B      : $ya", "#" + "-".repeat(9 + n), "#A $op B: $sb"
        )
        CalcResult(true, sb.toString(), steps = steps)
    }

    // ---------------- BCD ----------------
    fun binaryToBcd(a: String, bn: Boolean): CalcResult = guard {
        val x = cleanBin(a, bn)
        val dec = big(x).toString()
        val groups = dec.map { pad(Integer.toBinaryString(it - '0'), 4) }
        val steps = mutableListOf<String>()
        steps += tx(bn, "ধাপ ১: বাইনারি $x-কে ডেসিমালে রূপান্তর: $dec", "Step 1: convert binary $x to decimal: $dec")
        steps += tx(bn, "ধাপ ২: প্রতিটি ডেসিমাল অঙ্ককে আলাদাভাবে ৪ বিট বাইনারিতে লিখি (8421 কোড):", "Step 2: write each decimal digit as a separate 4-bit binary group (8421 code):")
        for ((i, d) in dec.withIndex()) steps += "#$d = ${groups[i]}"
        CalcResult(true, groups.joinToString(" "), steps = steps, note = tx(bn, "ডেসিমাল মান: $dec", "Decimal value: $dec"))
    }

    fun bcdToBinary(a: String, bn: Boolean): CalcResult = guard {
        var s = cleanBin(a, bn)
        var note = ""
        if (s.length % 4 != 0) {
            val padded = s.padStart(((s.length + 3) / 4) * 4, '0')
            note = tx(bn, "বামে 0 বসিয়ে ৪ বিটের গুণিতক করা হয়েছে: $padded", "Padded on the left to a multiple of 4 bits: $padded")
            s = padded
        }
        val steps = mutableListOf<String>()
        steps += tx(bn, "ধাপ ১: ডান দিক থেকে ৪ বিট করে ভাগ করে প্রতিটি গ্রুপকে ডেসিমাল অঙ্কে রূপান্তর করি:", "Step 1: split into 4-bit groups and convert each to a decimal digit:")
        val dec = StringBuilder()
        for (i in s.indices step 4) {
            val g = s.substring(i, i + 4)
            val v = g.toInt(2)
            if (v > 9) throw IllegalArgumentException(tx(bn, "$g একটি বৈধ BCD কোড নয় (সর্বোচ্চ 1001 = 9)।", "$g is not a valid BCD digit (maximum is 1001 = 9)."))
            dec.append(v)
            steps += "#$g = $v"
        }
        val value = BigInteger(dec.toString())
        steps += tx(bn, "ধাপ ২: ডেসিমাল সংখ্যা = $value", "Step 2: decimal number = $value")
        steps += tx(bn, "ধাপ ৩: $value-কে বাইনারিতে রূপান্তর = ${bin(value)}", "Step 3: convert $value to binary = ${bin(value)}")
        CalcResult(true, bin(value), steps = steps, note = note)
    }

    // ---------------- Gray code ----------------
    fun binaryToGray(a: String, bn: Boolean): CalcResult = guard {
        val x = cleanBin(a, bn)
        val sb = StringBuilder().append(x[0])
        val steps = mutableListOf<String>()
        steps += tx(bn, "নিয়ম: প্রথম (MSB) বিট একই থাকে। এরপর Gray বিট = আগের বাইনারি বিট XOR বর্তমান বাইনারি বিট।", "Rule: the first (MSB) bit stays the same. Each next Gray bit = previous binary bit XOR current binary bit.")
        steps += "#G1 = B1 = ${x[0]}"
        for (i in 1 until x.length) {
            val g = if (x[i - 1] != x[i]) '1' else '0'
            sb.append(g)
            if (i < 24) steps += "#G${i + 1} = ${x[i - 1]} ⊕ ${x[i]} = $g"
        }
        CalcResult(true, sb.toString(), steps = steps)
    }

    fun grayToBinary(a: String, bn: Boolean): CalcResult = guard {
        val g = cleanBin(a, bn)
        val sb = StringBuilder().append(g[0])
        val steps = mutableListOf<String>()
        steps += tx(bn, "নিয়ম: প্রথম (MSB) বিট একই থাকে। এরপর বাইনারি বিট = আগের বাইনারি বিট XOR বর্তমান Gray বিট।", "Rule: the first (MSB) bit stays the same. Each next binary bit = previous binary bit XOR current Gray bit.")
        steps += "#B1 = G1 = ${g[0]}"
        for (i in 1 until g.length) {
            val b = if (sb[i - 1] != g[i]) '1' else '0'
            if (i < 24) steps += "#B${i + 1} = ${sb[i - 1]} ⊕ ${g[i]} = $b"
            sb.append(b)
        }
        CalcResult(true, sb.toString(), steps = steps)
    }

    // ---------------- ASCII ----------------
    fun textToAscii(text: String, bn: Boolean): CalcResult {
        if (text.isEmpty()) return CalcResult.fail(tx(bn, "কিছু লিখুন।", "Enter some text."))
        if (text.length > 200) return CalcResult.fail(tx(bn, "সর্বোচ্চ ২০০ অক্ষর।", "Maximum 200 characters."))
        val steps = mutableListOf<String>()
        steps += tx(bn, "প্রতিটি অক্ষরের ASCII/Unicode কোড (ডেসিমাল, হেক্সা, ৮ বিট বাইনারি):", "ASCII/Unicode code of each character (decimal, hex, 8-bit binary):")
        val decs = mutableListOf<String>(); val bins = mutableListOf<String>()
        var nonAscii = false
        text.codePoints().toArray().forEach { cp ->
            if (cp > 127) nonAscii = true
            val label = when (cp) { 32 -> "␣"; 10 -> "\\n"; 9 -> "\\t"; else -> String(Character.toChars(cp)) }
            decs += cp.toString()
            bins += Integer.toBinaryString(cp).padStart(8, '0')
            if (decs.size <= 40) steps += "#$label = $cp = 0x${Integer.toHexString(cp).uppercase()} = ${Integer.toBinaryString(cp).padStart(8, '0')}"
        }
        return CalcResult(true, decs.joinToString(" "), steps = steps,
            note = (tx(bn, "বাইনারি: ", "Binary: ") + bins.joinToString(" ")) +
                if (nonAscii) tx(bn, "\n(ASCII-এর বাইরের অক্ষরের জন্য Unicode কোড দেখানো হয়েছে)", "\n(Unicode code points are shown for non-ASCII characters)") else "")
    }

    fun asciiToText(input: String, base: Int, bn: Boolean): CalcResult {
        val parts = input.trim().split(Regex("[\\s,]+")).filter { it.isNotEmpty() }
        if (parts.isEmpty()) return CalcResult.fail(tx(bn, "কোড লিখুন (স্পেস দিয়ে আলাদা)।", "Enter codes separated by spaces."))
        if (parts.size > 200) return CalcResult.fail(tx(bn, "সর্বোচ্চ ২০০টি কোড।", "Maximum 200 codes."))
        val sb = StringBuilder()
        val steps = mutableListOf<String>()
        for (p in parts) {
            val v = try { BigInteger(p, base) } catch (e: NumberFormatException) {
                return CalcResult.fail(tx(bn, "'$p' ${NumberSystem.baseName(base, true)} কোড হিসেবে বৈধ নয়।", "'$p' is not a valid ${NumberSystem.baseName(base, false)} code."))
            }
            if (v.signum() < 0 || v > BigInteger.valueOf(0x10FFFF) || v.toInt() in 0xD800..0xDFFF)
                return CalcResult.fail(tx(bn, "$p সীমার বাইরে (0 – 1114111)।", "$p is out of range (0 – 1114111)."))
            val cp = v.toInt()
            sb.appendCodePoint(cp)
            if (steps.size < 40) steps += "#$p → $cp → " + (if (cp < 32) tx(bn, "(কন্ট্রোল ক্যারেক্টার)", "(control character)") else String(Character.toChars(cp)))
        }
        return CalcResult(true, sb.toString(), steps = steps)
    }

    // ---------------- Units ----------------
    val unitNames = listOf("Bit", "Byte", "KB", "MB", "GB", "TB", "PB")

    fun convertUnit(raw: String, from: Int, to: Int, base1024: Boolean, bn: Boolean): CalcResult {
        val s = raw.trim()
        val v = try { BigDecimal(s) } catch (e: Exception) {
            return CalcResult.fail(tx(bn, "বৈধ সংখ্যা লিখুন।", "Enter a valid number."))
        }
        if (s.length > 60) return CalcResult.fail(tx(bn, "ইনপুট অনেক বড়।", "Input too long."))
        fun bitsOf(i: Int): BigDecimal = when (i) {
            0 -> BigDecimal.ONE
            else -> BigDecimal(8).multiply(BigDecimal(if (base1024) 1024 else 1000).pow(i - 1))
        }
        val bits = v.multiply(bitsOf(from))
        val res = bits.divide(bitsOf(to), 12, RoundingMode.HALF_UP).stripTrailingZeros()
        val out = res.toPlainString()
        val f = unitNames[from]; val t = unitNames[to]
        val k = if (base1024) 1024 else 1000
        val steps = listOf(
            tx(bn, "১ Byte = ৮ Bit, ১ KB = $k Byte, ১ MB = $k KB, ১ GB = $k MB, ১ TB = $k GB, ১ PB = $k TB", "1 Byte = 8 Bits, 1 KB = $k Bytes, 1 MB = $k KB, 1 GB = $k MB, 1 TB = $k GB, 1 PB = $k TB"),
            tx(bn, "ধাপ ১: ${v.toPlainString()} $f = ${bits.stripTrailingZeros().toPlainString()} Bit", "Step 1: ${v.toPlainString()} $f = ${bits.stripTrailingZeros().toPlainString()} bits"),
            tx(bn, "ধাপ ২: Bit থেকে $t-তে ভাগ করে পাই: $out $t", "Step 2: divide the bits by the size of one $t: $out $t")
        )
        return CalcResult(true, "$out $t", steps = steps)
    }

    // ---------------- Base calculator ----------------
    fun baseCalc(a: String, b: String, op: String, base: Int, bn: Boolean): CalcResult {
        val pa = try { NumberSystem.parse(a, base, bn) } catch (e: IllegalArgumentException) { return CalcResult.fail("A: " + e.message) }
        val pb = try { NumberSystem.parse(b, base, bn) } catch (e: IllegalArgumentException) { return CalcResult.fail("B: " + e.message) }
        if (pa.fracPart.isNotEmpty() || pb.fracPart.isNotEmpty())
            return CalcResult.fail(tx(bn, "এই ক্যালকুলেটরে শুধু পূর্ণসংখ্যা ব্যবহার করা যাবে।", "This calculator accepts integers only."))
        val x = BigInteger(pa.intPart, base).let { if (pa.negative) it.negate() else it }
        val y = BigInteger(pb.intPart, base).let { if (pb.negative) it.negate() else it }
        val r: BigInteger; var note = ""
        when (op) {
            "+" -> r = x.add(y)
            "−" -> r = x.subtract(y)
            "×" -> r = x.multiply(y)
            else -> {
                if (y.signum() == 0) return CalcResult.fail(tx(bn, "শূন্য দিয়ে ভাগ করা যায় না।", "Division by zero is not possible."))
                val qr = x.divideAndRemainder(y)
                r = qr[0]
                note = tx(bn, "ভাগশেষ: ${qr[1].toString(base).uppercase()}", "Remainder: ${qr[1].toString(base).uppercase()}")
            }
        }
        val out = r.toString(base).uppercase()
        val steps = listOf(
            tx(bn, "ধাপ ১: দুটি সংখ্যাকে ডেসিমালে রূপান্তর: ${x} এবং ${y}", "Step 1: convert both numbers to decimal: $x and $y"),
            tx(bn, "ধাপ ২: ডেসিমালে হিসাব: $x $op $y = $r","Step 2: calculate in decimal: $x $op $y = $r"),
            tx(bn, "ধাপ ৩: ফলাফলকে বেস $base-এ রূপান্তর: $out", "Step 3: convert the result back to base $base: $out")
        )
        return CalcResult(true, out, steps = steps, note = note.ifEmpty { tx(bn, "ডেসিমাল মান: $r", "Decimal value: $r") })
    }
}
