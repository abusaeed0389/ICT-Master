package com.abusaeed.ictmaster.logic

sealed class Expr {
    data class Const(val v: Boolean) : Expr()
    data class Var(val c: Char) : Expr()
    data class Not(val e: Expr) : Expr()
    data class And(val l: Expr, val r: Expr) : Expr()
    data class Or(val l: Expr, val r: Expr) : Expr()
    data class Xor(val l: Expr, val r: Expr) : Expr()

    fun eval(env: Map<Char, Boolean>): Boolean = when (this) {
        is Const -> v
        is Var -> env[c] ?: false
        is Not -> !e.eval(env)
        is And -> l.eval(env) && r.eval(env)
        is Or -> l.eval(env) || r.eval(env)
        is Xor -> l.eval(env) != r.eval(env)
    }

    fun vars(): Set<Char> = when (this) {
        is Const -> emptySet()
        is Var -> setOf(c)
        is Not -> e.vars()
        is And -> l.vars() + r.vars()
        is Or -> l.vars() + r.vars()
        is Xor -> l.vars() + r.vars()
    }
}

class ParseException(message: String) : Exception(message)

object BooleanAlgebra {
    const val MAX_VARS = 6

    private enum class T { VAR, CONST, NOT, POSTNOT, AND, OR, XOR, NAND, NOR, XNOR, LP, RP }
    private data class Tok(val t: T, val ch: Char = ' ')

    private fun tokenize(src: String, bn: Boolean): List<Tok> {
        val out = mutableListOf<Tok>()
        var i = 0
        while (i < src.length) {
            val c = src[i]
            when {
                c.isWhitespace() -> i++
                c.isLetter() -> {
                    var j = i
                    while (j < src.length && src[j].isLetter()) j++
                    val run = src.substring(i, j)
                    val word = when (run.uppercase()) {
                        "AND" -> T.AND; "OR" -> T.OR; "NOT" -> T.NOT; "XOR" -> T.XOR
                        "NAND" -> T.NAND; "NOR" -> T.NOR; "XNOR" -> T.XNOR
                        else -> null
                    }
                    if (word != null) out += Tok(word)
                    else for (ch in run) {
                        if (!ch.isLetter() || ch.code > 127) throw ParseException(tx(bn, "'$ch' ব্যবহার করা যাবে না। শুধু A-Z ভেরিয়েবল ব্যবহার করুন।", "'$ch' is not allowed. Use A-Z variables."))
                        out += Tok(T.VAR, ch.uppercaseChar())
                    }
                    i = j
                }
                c == '0' || c == '1' -> { out += Tok(T.CONST, c); i++ }
                c == '(' -> { out += Tok(T.LP); i++ }
                c == ')' -> { out += Tok(T.RP); i++ }
                c == '!' || c == '~' || c == '¬' -> { out += Tok(T.NOT); i++ }
                c == '\'' || c == '′' || c == '’' -> { out += Tok(T.POSTNOT); i++ }
                c == '*' || c == '&' || c == '.' || c == '·' || c == '∧' || c == '×' -> { out += Tok(T.AND); i++ }
                c == '+' || c == '|' || c == '∨' -> { out += Tok(T.OR); i++ }
                c == '^' || c == '⊕' -> { out += Tok(T.XOR); i++ }
                else -> throw ParseException(tx(bn, "'$c' চিহ্নটি বোঝা যায়নি।", "Unrecognised symbol '$c'."))
            }
        }
        return out
    }

    private class Parser(val toks: List<Tok>, val bn: Boolean) {
        var pos = 0
        fun peek(): Tok? = toks.getOrNull(pos)

        fun parse(): Expr {
            if (toks.isEmpty()) throw ParseException(tx(bn, "একটি এক্সপ্রেশন লিখুন।", "Enter an expression."))
            val e = parseOr()
            if (pos < toks.size) throw ParseException(tx(bn, "এক্সপ্রেশনে ভুল আছে (অপ্রত্যাশিত অংশ)।", "Syntax error (unexpected token)."))
            return e
        }

        fun parseOr(): Expr {
            var l = parseXor()
            while (true) {
                val t = peek()?.t
                if (t == T.OR) { pos++; l = Expr.Or(l, parseXor()) }
                else if (t == T.NOR) { pos++; l = Expr.Not(Expr.Or(l, parseXor())) }
                else break
            }
            return l
        }

        fun parseXor(): Expr {
            var l = parseAnd()
            while (true) {
                val t = peek()?.t
                if (t == T.XOR) { pos++; l = Expr.Xor(l, parseAnd()) }
                else if (t == T.XNOR) { pos++; l = Expr.Not(Expr.Xor(l, parseAnd())) }
                else break
            }
            return l
        }

        fun startsOperand(t: T?) = t == T.VAR || t == T.CONST || t == T.LP || t == T.NOT

        fun parseAnd(): Expr {
            var l = parseUnary()
            while (true) {
                val t = peek()?.t
                if (t == T.AND) { pos++; l = Expr.And(l, parseUnary()) }
                else if (t == T.NAND) { pos++; l = Expr.Not(Expr.And(l, parseUnary())) }
                else if (startsOperand(t)) l = Expr.And(l, parseUnary())   // implicit AND: AB, A(B+C)
                else break
            }
            return l
        }

        fun parseUnary(): Expr {
            if (peek()?.t == T.NOT) { pos++; return Expr.Not(parseUnary()) }
            return parsePostfix()
        }

        fun parsePostfix(): Expr {
            var e = parsePrimary()
            while (peek()?.t == T.POSTNOT) { pos++; e = Expr.Not(e) }
            return e
        }

        fun parsePrimary(): Expr {
            val t = peek() ?: throw ParseException(tx(bn, "এক্সপ্রেশন অসম্পূর্ণ।", "The expression is incomplete."))
            pos++
            return when (t.t) {
                T.VAR -> Expr.Var(t.ch)
                T.CONST -> Expr.Const(t.ch == '1')
                T.LP -> {
                    val e = parseOr()
                    if (peek()?.t != T.RP) throw ParseException(tx(bn, "বন্ধনী ')' বন্ধ করা হয়নি।", "Missing closing parenthesis ')'."))
                    pos++
                    e
                }
                else -> throw ParseException(tx(bn, "এখানে ভেরিয়েবল বা বন্ধনী আশা করা হয়েছিল।", "A variable or parenthesis was expected here."))
            }
        }
    }

    fun parse(src: String, bn: Boolean): Expr {
        if (src.length > 200) throw ParseException(tx(bn, "এক্সপ্রেশন অনেক বড়।", "Expression is too long."))
        return Parser(tokenize(src, bn), bn).parse()
    }

    fun format(e: Expr): String = fmt(e, 0)

    private fun fmt(e: Expr, parent: Int): String = when (e) {
        is Expr.Const -> if (e.v) "1" else "0"
        is Expr.Var -> e.c.toString()
        is Expr.Not -> {
            val inner = e.e
            if (inner is Expr.Var || inner is Expr.Const) fmt(inner, 4) + "′" else "(" + fmt(inner, 0) + ")′"
        }
        is Expr.And -> wrap(fmt(e.l, 3) + "·" + fmt(e.r, 3), 3, parent)
        is Expr.Xor -> wrap(fmt(e.l, 2) + " ⊕ " + fmt(e.r, 2), 2, parent)
        is Expr.Or -> wrap(fmt(e.l, 1) + " + " + fmt(e.r, 1), 1, parent)
    }

    private fun wrap(s: String, prec: Int, parent: Int) = if (prec < parent) "($s)" else s

    class Table(val vars: List<Char>, val rows: List<Pair<List<Int>, Int>>) {
        val minterms: List<Int> get() = rows.withIndex().filter { it.value.second == 1 }.map { it.index }
    }

    fun truthTable(e: Expr, bn: Boolean): Table {
        val vars = e.vars().sorted()
        if (vars.size > MAX_VARS) throw ParseException(tx(bn, "সর্বোচ্চ $MAX_VARS টি ভেরিয়েবল সাপোর্ট করা হয়।", "At most $MAX_VARS variables are supported."))
        val n = vars.size
        val rows = (0 until (1 shl n)).map { m ->
            val bits = (0 until n).map { (m shr (n - 1 - it)) and 1 }
            val env = vars.indices.associate { vars[it] to (bits[it] == 1) }
            bits to (if (e.eval(env)) 1 else 0)
        }
        return Table(vars, rows)
    }

    // ---------- Quine–McCluskey ----------
    data class Implicant(val bits: Int, val dash: Int)   // dash bit = 1 means variable eliminated

    private fun covers(imp: Implicant, m: Int) = (m and imp.dash.inv()) == (imp.bits and imp.dash.inv())

    fun primeImplicants(minterms: List<Int>, n: Int): List<Implicant> {
        var current = minterms.map { Implicant(it, 0) }.toSet()
        val primes = mutableSetOf<Implicant>()
        while (current.isNotEmpty()) {
            val used = mutableSetOf<Implicant>()
            val next = mutableSetOf<Implicant>()
            val list = current.toList()
            for (i in list.indices) for (j in i + 1 until list.size) {
                val a = list[i]; val b = list[j]
                if (a.dash != b.dash) continue
                val diff = a.bits xor b.bits
                if (diff != 0 && (diff and (diff - 1)) == 0) {
                    next += Implicant(a.bits and diff.inv(), a.dash or diff)
                    used += a; used += b
                }
            }
            primes += current - used
            current = next
        }
        return primes.toList()
    }

    fun minimalCover(minterms: List<Int>, primes: List<Implicant>): List<Implicant> {
        val chosen = mutableListOf<Implicant>()
        val remaining = minterms.toMutableSet()
        // essential prime implicants
        for (m in minterms) {
            val c = primes.filter { covers(it, m) }
            if (c.size == 1 && c[0] !in chosen) chosen += c[0]
        }
        for (imp in chosen) remaining.removeAll { covers(imp, it) }
        while (remaining.isNotEmpty()) {
            val best = primes.filter { it !in chosen }.maxByOrNull { p -> remaining.count { covers(p, it) } } ?: break
            chosen += best
            remaining.removeAll { covers(best, it) }
        }
        return chosen
    }

    private fun implicantToString(imp: Implicant, vars: List<Char>): String {
        val n = vars.size
        val sb = StringBuilder()
        for (i in 0 until n) {
            val bit = n - 1 - i
            if ((imp.dash shr bit) and 1 == 1) continue
            sb.append(vars[i])
            if ((imp.bits shr bit) and 1 == 0) sb.append('′')
        }
        return if (sb.isEmpty()) "1" else sb.toString()
    }

    fun simplify(table: Table): String {
        val n = table.vars.size
        val mins = table.minterms
        if (mins.isEmpty()) return "0"
        if (mins.size == (1 shl n)) return "1"
        val cover = minimalCover(mins, primeImplicants(mins, n))
        return cover.map { implicantToString(it, table.vars) }.sorted().joinToString(" + ")
    }

    /** Evaluates the minimal SOP string back through the parser — used to verify correctness. */
    fun fullAnalysis(src: String, bn: Boolean): CalcResult {
        val expr = try { parse(src, bn) } catch (e: ParseException) { return CalcResult.fail(e.message ?: "") }
        val table = try { truthTable(expr, bn) } catch (e: ParseException) { return CalcResult.fail(e.message ?: "") }
        val simplified = simplify(table)
        val steps = mutableListOf<String>()
        steps += tx(bn, "এক্সপ্রেশন: ${format(expr)}", "Expression: ${format(expr)}")
        if (table.vars.isEmpty()) {
            steps += tx(bn, "কোনো ভেরিয়েবল নেই; মান = ${table.rows[0].second}", "No variables; value = ${table.rows[0].second}")
        } else {
            steps += tx(bn, "ভেরিয়েবল: ${table.vars.joinToString(", ")} (${1 shl table.vars.size}টি সারি)", "Variables: ${table.vars.joinToString(", ")} (${1 shl table.vars.size} rows)")
            val mins = table.minterms
            steps += tx(bn, "যেসব সারিতে আউটপুট 1, সেগুলোর মিনটার্ম: Σm(${mins.joinToString(", ")})", "Rows where the output is 1 (minterms): Σm(${mins.joinToString(", ")})")
            if (mins.isNotEmpty() && mins.size != (1 shl table.vars.size)) {
                val primes = primeImplicants(mins, table.vars.size)
                steps += tx(bn, "প্রতিবেশী মিনটার্ম একত্র করে (কুইন-ম্যাক্লাস্কি পদ্ধতি) প্রাইম ইমপ্লিক্যান্ট: ${primes.map { implicantToString(it, table.vars) }.sorted().joinToString(", ")}",
                    "Prime implicants (Quine–McCluskey): ${primes.map { implicantToString(it, table.vars) }.sorted().joinToString(", ")}")
            }
            steps += tx(bn, "সরলীকৃত রূপ (Sum of Products): $simplified", "Simplified form (Sum of Products): $simplified")
        }
        return CalcResult(true, simplified, steps = steps)
    }
}
