package com.abusaeed.ictmaster.logic

enum class Gate(val bnName: String, val inputs: Int, val symbol: String) {
    AND("AND গেট", 2, "A · B"),
    OR("OR গেট", 2, "A + B"),
    NOT("NOT গেট", 1, "A′"),
    NAND("NAND গেট", 2, "(A · B)′"),
    NOR("NOR গেট", 2, "(A + B)′"),
    XOR("XOR গেট", 2, "A ⊕ B"),
    XNOR("XNOR গেট", 2, "(A ⊕ B)′");

    val enName: String get() = "$name gate"

    fun eval(a: Boolean, b: Boolean = false): Boolean = when (this) {
        AND -> a && b
        OR -> a || b
        NOT -> !a
        NAND -> !(a && b)
        NOR -> !(a || b)
        XOR -> a != b
        XNOR -> a == b
    }

    fun eval(a: Int, b: Int = 0): Int = if (eval(a == 1, b == 1)) 1 else 0

    fun truthTable(): List<Triple<Int, Int, Int>> =
        if (inputs == 1) listOf(0, 1).map { Triple(it, -1, eval(it)) }
        else listOf(0, 1).flatMap { a -> listOf(0, 1).map { b -> Triple(a, b, eval(a, b)) } }

    fun explanation(bn: Boolean): String = when (this) {
        AND -> tx(bn, "AND গেটের আউটপুট তখনই 1 হয় যখন সবগুলো ইনপুট 1 থাকে। যেকোনো একটি ইনপুট 0 হলে আউটপুট 0। এটি গুণের মতো কাজ করে (A·B)।",
            "An AND gate outputs 1 only when all inputs are 1. If any input is 0 the output is 0. It behaves like multiplication (A·B).")
        OR -> tx(bn, "OR গেটের আউটপুট 1 হয় যদি অন্তত একটি ইনপুট 1 হয়। সব ইনপুট 0 হলেই কেবল আউটপুট 0। এটি যোগের মতো কাজ করে (A+B)।",
            "An OR gate outputs 1 when at least one input is 1. The output is 0 only when all inputs are 0. It behaves like addition (A+B).")
        NOT -> tx(bn, "NOT গেটের একটিমাত্র ইনপুট থাকে এবং এটি ইনপুটের বিপরীত মান দেয়। তাই একে ইনভার্টারও বলে। 0 হলে 1, 1 হলে 0।",
            "A NOT gate has a single input and outputs its opposite. It is also called an inverter: 0 gives 1 and 1 gives 0.")
        NAND -> tx(bn, "NAND = NOT + AND। AND গেটের আউটপুটকে উল্টে দিলে NAND পাওয়া যায়। তাই কেবল দুটি ইনপুটই 1 হলে আউটপুট 0, অন্যথায় 1। NAND একটি সার্বজনীন (Universal) গেট।",
            "NAND = NOT + AND. It inverts the AND result, so the output is 0 only when both inputs are 1. NAND is a universal gate.")
        NOR -> tx(bn, "NOR = NOT + OR। OR গেটের আউটপুটকে উল্টে দিলে NOR পাওয়া যায়। তাই কেবল সব ইনপুট 0 হলে আউটপুট 1। NOR-ও একটি সার্বজনীন (Universal) গেট।",
            "NOR = NOT + OR. It inverts the OR result, so the output is 1 only when all inputs are 0. NOR is also a universal gate.")
        XOR -> tx(bn, "XOR (Exclusive OR) গেটের আউটপুট 1 হয় যখন দুটি ইনপুট ভিন্ন (একটি 0, অন্যটি 1) হয়। ইনপুট একই হলে আউটপুট 0। বাইনারি যোগের সাম বিট এটি দিয়েই পাওয়া যায়।",
            "An XOR (exclusive OR) gate outputs 1 when the two inputs are different. Equal inputs give 0. It produces the sum bit in binary addition.")
        XNOR -> tx(bn, "XNOR গেট হলো XOR-এর বিপরীত। দুটি ইনপুট একই হলে আউটপুট 1, ভিন্ন হলে 0। একে সমতা (equality) গেটও বলা হয়।",
            "An XNOR gate is the inverse of XOR. It outputs 1 when both inputs are equal and 0 when they differ. It is also called the equality gate.")
    }
}
