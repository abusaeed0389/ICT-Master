package com.abusaeed.ictmaster.logic

import java.math.BigDecimal
import java.math.BigInteger

/**
 * Result of any calculation tool.
 * Steps starting with '#' are rendered in a monospace font by the UI (the '#' is stripped).
 */
data class CalcResult(
    val ok: Boolean,
    val output: String = "",
    val error: String = "",
    val steps: List<String> = emptyList(),
    val note: String = ""
) {
    companion object {
        fun fail(msg: String) = CalcResult(false, error = msg)
    }
}

internal fun tx(bn: Boolean, b: String, e: String) = if (bn) b else e

/** Exact (BigInteger based) number-system conversion with step-by-step explanation. */
object NumberSystem {
    private const val DIGITS = "0123456789ABCDEF"
    val bases = listOf(2, 8, 10, 16)
    const val MAX_INPUT_LENGTH = 500

    fun baseName(base: Int, bn: Boolean): String = when (base) {
        2 -> tx(bn, "বাইনারি", "Binary")
        8 -> tx(bn, "অক্টাল", "Octal")
        10 -> tx(bn, "ডেসিমাল", "Decimal")
        16 -> tx(bn, "হেক্সাডেসিমাল", "Hexadecimal")
        else -> "Base $base"
    }

    fun validDigits(base: Int): String = when (base) {
        2 -> "0, 1"
        8 -> "0-7"
        10 -> "0-9"
        16 -> "0-9, A-F"
        else -> ""
    }

    private fun isPow2(b: Int) = b == 2 || b == 8 || b == 16
    private fun bitsPer(b: Int) = when (b) { 2 -> 1; 8 -> 3; else -> 4 }

    class Parsed(val negative: Boolean, val intPart: String, val fracPart: String)

    /** Throws IllegalArgumentException with a localized message when the input is invalid. */
    fun parse(raw: String, base: Int, bn: Boolean): Parsed {
        var s = raw.trim()
        if (s.isEmpty()) throw IllegalArgumentException(tx(bn, "একটি সংখ্যা লিখুন।", "Please enter a number."))
        if (s.length > MAX_INPUT_LENGTH) throw IllegalArgumentException(
            tx(bn, "ইনপুট অনেক বড়। সর্বোচ্চ $MAX_INPUT_LENGTH অক্ষর।", "Input too long. Maximum $MAX_INPUT_LENGTH characters.")
        )
        var neg = false
        if (s.startsWith("-")) { neg = true; s = s.substring(1) } else if (s.startsWith("+")) s = s.substring(1)
        if (s.count { it == '.' } > 1) throw IllegalArgumentException(
            tx(bn, "একাধিক দশমিক বিন্দু (.) থাকতে পারবে না।", "Only one radix point (.) is allowed.")
        )
        for (c in s) {
            if (c == '.') continue
            if (!(DIGITS.indexOf(c.uppercaseChar()).let { it in 0 until base })) {
                throw IllegalArgumentException(
                    tx(
                        bn,
                        "'$c' অক্ষরটি ${baseName(base, true)} সংখ্যায় বৈধ নয়। বৈধ অঙ্ক: ${validDigits(base)}",
                        "'$c' is not valid in a ${baseName(base, false)} number. Valid digits: ${validDigits(base)}"
                    )
                )
            }
        }
        val parts = s.uppercase().split(".")
        var ip = parts[0]
        val fp = if (parts.size > 1) parts[1] else ""
        if (ip.isEmpty() && fp.isEmpty()) throw IllegalArgumentException(tx(bn, "কমপক্ষে একটি অঙ্ক লিখুন।", "Enter at least one digit."))
        ip = ip.trimStart('0')
        if (ip.isEmpty()) ip = "0"
        return Parsed(neg, ip, fp.trimEnd('0'))
    }

    fun convert(raw: String, from: Int, to: Int, bn: Boolean): CalcResult {
        val p = try { parse(raw, from, bn) } catch (e: IllegalArgumentException) { return CalcResult.fail(e.message ?: "") }

        val bFrom = BigInteger.valueOf(from.toLong())
        val bTo = BigInteger.valueOf(to.toLong())
        val intVal = BigInteger(p.intPart, from)
        val fn = if (p.fracPart.isEmpty()) BigInteger.ZERO else BigInteger(p.fracPart, from)
        val fd = bFrom.pow(p.fracPart.length)
        val isZero = intVal.signum() == 0 && fn.signum() == 0
        val sign = if (p.negative && !isZero) "-" else ""

        val intOut = intVal.toString(to).uppercase()
        val limit = if (isPow2(from)) 4 * p.fracPart.length + 8 else 24
        val frac = StringBuilder()
        var num = fn
        var exact = true
        while (num.signum() != 0) {
            if (frac.length >= limit) { exact = false; break }
            num = num.multiply(bTo)
            val d = num.divide(fd)
            num = num.mod(fd)
            frac.append(DIGITS[d.toInt()])
        }
        val output = sign + intOut + (if (frac.isNotEmpty()) ".$frac" else "")

        val steps = mutableListOf<String>()
        val fromN = baseName(from, bn)
        val toN = baseName(to, bn)
        steps += tx(bn, "$fromN (বেস $from) থেকে $toN (বেস $to)", "$fromN (base $from) to $toN (base $to)")
        if (sign.isNotEmpty()) steps += tx(bn, "ঋণাত্মক চিহ্ন (-) আলাদা রেখে সংখ্যার মান রূপান্তর করা হলো।", "The minus sign is kept aside; only the magnitude is converted.")

        when {
            from == to -> steps += tx(bn, "বেস একই, তাই সংখ্যার মান অপরিবর্তিত থাকে।", "Both bases are the same, so the value stays unchanged.")
            from == 10 -> decimalTo(p, intVal, fn, fd, to, bn, steps)
            to == 10 -> toDecimal(p, from, bn, steps)
            else -> viaBinary(p, from, to, bn, steps)
        }
        steps += tx(bn, "ফলাফল: $output", "Result: $output")

        val note = if (!exact) tx(
            bn,
            "ভগ্নাংশ অংশ সসীম নয়; প্রথম ${frac.length} অঙ্ক পর্যন্ত দেখানো হয়েছে (আসন্ন মান)।",
            "The fractional part does not terminate; shown up to ${frac.length} digits (approximate)."
        ) else ""
        return CalcResult(true, output, steps = steps, note = note)
    }

    // ---------- decimal -> other ----------
    private fun dd(d: Int) = if (d >= 10) "$d (${DIGITS[d]})" else "$d"

    private fun decimalTo(
        p: Parsed, intVal: BigInteger, fn: BigInteger, fd: BigInteger,
        to: Int, bn: Boolean, steps: MutableList<String>
    ) {
        val bTo = BigInteger.valueOf(to.toLong())
        steps += tx(bn, "পূর্ণসংখ্যা অংশ ${p.intPart}-কে বারবার $to দিয়ে ভাগ করি এবং ভাগশেষ লিখি:", "Divide the integer part ${p.intPart} repeatedly by $to and note the remainders:")
        var q = intVal
        if (q.signum() == 0) {
            steps += "#0 ÷ $to = 0, ${tx(bn, "ভাগশেষ", "remainder")} 0"
        }
        var cnt = 0
        val rems = StringBuilder()
        while (q.signum() > 0) {
            val qr = q.divideAndRemainder(bTo)
            rems.append(DIGITS[qr[1].toInt()])
            if (cnt < 20) steps += "#$q ÷ $to = ${qr[0]}, ${tx(bn, "ভাগশেষ", "remainder")} ${dd(qr[1].toInt())}"
            q = qr[0]
            cnt++
        }
        if (cnt > 20) steps += tx(bn, "… মোট $cnt ধাপ (প্রথম ২০টি দেখানো হলো)", "… $cnt steps in total (first 20 shown)")
        steps += tx(bn, "ভাগশেষগুলো নিচ থেকে উপরের দিকে সাজালে পাওয়া যায়: ${intVal.toString(to).uppercase()}", "Reading the remainders from bottom to top gives: ${intVal.toString(to).uppercase()}")

        if (p.fracPart.isNotEmpty()) {
            val k = p.fracPart.length
            steps += tx(bn, "ভগ্নাংশ অংশ 0.${p.fracPart}-কে বারবার $to দিয়ে গুণ করি; প্রতিবার পূর্ণ অংশ লিখি:", "Multiply the fractional part 0.${p.fracPart} repeatedly by $to; note each integer part:")
            var cur = fn
            var c = 0
            val digs = StringBuilder()
            while (cur.signum() != 0 && c < 12) {
                val prev = cur.toString().padStart(k, '0')
                cur = cur.multiply(bTo)
                val d = cur.divide(fd)
                cur = cur.mod(fd)
                digs.append(DIGITS[d.toInt()])
                steps += "#0.$prev × $to = $d.${cur.toString().padStart(k, '0')}  →  ${dd(d.toInt())}"
                c++
            }
            if (cur.signum() != 0) steps += tx(bn, "… গুণ প্রক্রিয়া চলতে থাকবে (প্রথম ১২ ধাপ দেখানো হলো)", "… the process continues (first 12 steps shown)")
            steps += tx(bn, "পূর্ণ অংশগুলো ওপর থেকে নিচে সাজালে ভগ্নাংশ: .$digs", "Reading the integer parts from top to bottom gives the fraction: .$digs")
        }
    }

    // ---------- other -> decimal ----------
    private fun digLabel(c: Char, base: Int): String {
        val v = DIGITS.indexOf(c)
        return if (base == 16 && v >= 10) "$c($v)" else "$c"
    }

    private fun toDecimal(p: Parsed, from: Int, bn: Boolean, steps: MutableList<String>) {
        val bFrom = BigInteger.valueOf(from.toLong())
        steps += tx(
            bn,
            "প্রতিটি অঙ্ককে তার স্থানীয় মান (বেস $from-এর ঘাত) দিয়ে গুণ করে যোগ করি:",
            "Multiply each digit by its place value (a power of $from) and add:"
        )
        val n = p.intPart.length
        val termsSym = mutableListOf<String>()
        val termsVal = mutableListOf<String>()
        var total = BigDecimal.ZERO
        for ((i, c) in p.intPart.withIndex()) {
            val pos = n - 1 - i
            val v = DIGITS.indexOf(c)
            val value = BigInteger.valueOf(v.toLong()).multiply(bFrom.pow(pos))
            termsSym += "${digLabel(c, from)}×$from^$pos"
            termsVal += value.toString()
            total = total.add(BigDecimal(value))
        }
        for ((j, c) in p.fracPart.withIndex()) {
            val pos = j + 1
            val v = DIGITS.indexOf(c)
            val value = BigDecimal(v).divide(BigDecimal(bFrom.pow(pos)))
            termsSym += "${digLabel(c, from)}×$from^-$pos"
            termsVal += value.stripTrailingZeros().toPlainString()
            total = total.add(value)
        }
        steps += "#" + capJoin(termsSym)
        steps += "#= " + capJoin(termsVal)
        steps += "#= ${total.stripTrailingZeros().toPlainString()}"
    }

    private fun capJoin(list: List<String>): String =
        if (list.size <= 16) list.joinToString(" + ")
        else list.take(8).joinToString(" + ") + " + … + " + list.takeLast(3).joinToString(" + ")

    // ---------- binary / octal / hex via binary ----------
    private fun toBinaryParts(p: Parsed, from: Int): Pair<String, String> {
        if (from == 2) return p.intPart to p.fracPart
        val k = bitsPer(from)
        fun conv(s: String) = s.map { Integer.toBinaryString(DIGITS.indexOf(it)).padStart(k, '0') }.joinToString("")
        val bi = conv(p.intPart).trimStart('0').ifEmpty { "0" }
        val bf = conv(p.fracPart).trimEnd('0')
        return bi to bf
    }

    private fun viaBinary(p: Parsed, from: Int, to: Int, bn: Boolean, steps: MutableList<String>) {
        val (bi, bf) = toBinaryParts(p, from)
        if (from != 2) {
            val k = bitsPer(from)
            steps += tx(
                bn,
                "ধাপ ১: প্রতিটি ${baseName(from, true)} অঙ্ককে $k বিট বাইনারিতে লিখি:",
                "Step 1: write each ${baseName(from, false)} digit as $k binary bits:"
            )
            val all = p.intPart + p.fracPart
            val shown = all.take(24)
            for (c in shown) steps += "#$c = ${Integer.toBinaryString(DIGITS.indexOf(c)).padStart(k, '0')}"
            if (all.length > 24) steps += "…"
            steps += tx(bn, "বাইনারি: $bi${if (bf.isNotEmpty()) ".$bf" else ""}", "Binary: $bi${if (bf.isNotEmpty()) ".$bf" else ""}")
        }
        if (to != 2) {
            val k = bitsPer(to)
            steps += tx(
                bn,
                "${if (from != 2) "ধাপ ২" else "ধাপ ১"}: বাইনারি সংখ্যাকে ডান দিক (দশমিকের বাম পাশে) থেকে $k বিট করে ভাগ করি; ভগ্নাংশে বাম থেকে ভাগ করি। প্রয়োজনে 0 বসাই:",
                "${if (from != 2) "Step 2" else "Step 1"}: group the bits in $k's from the radix point (integer part from the right, fraction from the left), padding with 0:"
            )
            val ipad = bi.padStart(((bi.length + k - 1) / k) * k, '0')
            val fpad = bf.padEnd(((bf.length + k - 1) / k) * k, '0')
            var shown = 0
            val total = ipad.length / k + fpad.length / k
            fun group(s: String) {
                for (i in s.indices step k) {
                    if (shown++ >= 24) return
                    val g = s.substring(i, i + k)
                    steps += "#$g = ${DIGITS[g.toInt(2)]}"
                }
            }
            group(ipad)
            if (fpad.isNotEmpty()) group(fpad)
            if (total > 24) steps += "…"
        }
    }
}
