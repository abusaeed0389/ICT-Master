@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(label, Modifier.weight(0.4f), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, Modifier.weight(0.6f), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    Screen(title = tr("অ্যাপ সম্পর্কে", "About application"), onBack = onBack) {
        Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            GlyphBadge("ICT", 88.dp)
            Text("ICT Master", style = MaterialTheme.typography.headlineSmall)
            Text(tr("সংস্করণ $APP_VERSION", "Version $APP_VERSION"), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                tr("HSC ICT শিক্ষার্থীদের জন্য অফলাইন টুলস, কুইজ ও ধাপে ধাপে সমাধান।", "Offline tools, quizzes and step-by-step solutions for HSC ICT students."),
                textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium
            )
        }

        AppCard {
            Text(tr("অ্যাপের তথ্য", "App information"), style = MaterialTheme.typography.titleMedium)
            InfoRow(tr("অ্যাপের নাম", "Application name"), "ICT Master")
            InfoRow(tr("সংস্করণ", "Version"), APP_VERSION)
            InfoRow(tr("ডেভেলপার", "Developer"), DEV_NAME)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(tr("ডেভেলপার পোর্টফোলিও", "Developer Portfolio"), Modifier.weight(0.4f), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Box(Modifier.weight(0.6f).heightIn(min = 48.dp).clickable(onClickLabel = tr("পোর্টফোলিও খুলুন", "Open portfolio"), role = Role.Button) { openUrl(ctx, DEV_URL) }, contentAlignment = Alignment.CenterStart) {
                    Text(DEV_URL, color = MaterialTheme.colorScheme.tertiary, textDecoration = TextDecoration.Underline, style = MaterialTheme.typography.bodyMedium)
                }
            }
            InfoRow(tr("প্ল্যাটফর্ম", "Platform"), tr("Android 9 (API 28) বা তার উপরে", "Android 9 (API 28) and above"))
            InfoRow(tr("ভাষা", "Languages"), tr("বাংলা, English", "Bangla, English"))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { DeveloperCredit() }
        }

        AppCard {
            Text(tr("বৈশিষ্ট্য", "Highlights"), style = MaterialTheme.typography.titleMedium)
            Text(
                tr(
                    "• সম্পূর্ণ অফলাইন, ইন্টারনেট ছাড়াই সব ফিচার\n• কোনো বিজ্ঞাপন নেই, অ্যাকাউন্ট লাগে না\n• কোনো পারমিশন লাগে না\n• হালকা ও কম RAM-এর ফোনের জন্য উপযোগী",
                    "• Fully offline, every core feature works without internet\n• No ads, no account needed\n• No permissions required\n• Lightweight and suited to low-RAM phones"
                ),
                style = MaterialTheme.typography.bodyMedium
            )
        }
        AppCard {
            Text(tr("প্রাইভেসি", "Privacy"), style = MaterialTheme.typography.titleMedium)
            Text(
                tr("কোনো ব্যক্তিগত তথ্য সংগ্রহ বা শেয়ার করা হয় না। সব ডেটা আপনার ডিভাইসেই থাকে। অনুশীলনের প্রশ্নগুলো এই অ্যাপের জন্য লেখা মৌলিক প্রশ্ন, বোর্ডের অফিশিয়াল প্রশ্ন নয়।",
                    "No personal data is collected or shared. All data stays on your device. Practice questions are original and not official board questions."),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
