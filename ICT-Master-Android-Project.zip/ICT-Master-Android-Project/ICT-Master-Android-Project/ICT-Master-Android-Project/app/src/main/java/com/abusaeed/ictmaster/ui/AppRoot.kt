@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.abusaeed.ictmaster.data.AppState
import com.abusaeed.ictmaster.data.Tools

private class Tab(val route: String, val bn: String, val en: String, val on: ImageVector, val off: ImageVector)

private val TABS = listOf(
    Tab("home", "হোম", "Home", Icons.Filled.Home, Icons.Outlined.Home),
    Tab("tools", "টুলস", "Tools", Icons.Filled.Build, Icons.Outlined.Build),
    Tab("practice", "অনুশীলন", "Practice", Icons.Filled.CheckCircle, Icons.Outlined.CheckCircle),
    Tab("history", "ইতিহাস", "History", Icons.Filled.DateRange, Icons.Outlined.DateRange),
    Tab("settings", "সেটিংস", "Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
)

private fun NavHostController.goTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun AppRoot(app: AppState) {
    ICTMasterTheme(app) {
        val nav = rememberNavController()
        val entry by nav.currentBackStackEntryAsState()
        val route = entry?.destination?.route
        val showBar = TABS.any { it.route == route }
        val openTool: (String) -> Unit = { id -> nav.navigate("tool/$id") { launchSingleTop = true } }

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (showBar) NavigationBar {
                    TABS.forEach { t ->
                        val selected = route == t.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = { if (!selected) nav.goTab(t.route) },
                            icon = { Icon(if (selected) t.on else t.off, contentDescription = null) },
                            label = { Text(tr(t.bn, t.en)) }
                        )
                    }
                }
            }
        ) { pad ->
            NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
                composable("home") { HomeScreen(onOpenTool = openTool, onTab = { nav.goTab(it) }, onSearch = { nav.navigate("search") }) }
                composable("tools") { ToolsScreen(onOpenTool = openTool) }
                composable("practice") { PracticeScreen() }
                composable("history") { HistoryScreen(onOpen = openTool) }
                composable("settings") { SettingsScreen(onAbout = { nav.navigate("about") }) }
                composable("search") { SearchScreen(onBack = { nav.popBackStack() }, onOpenTool = openTool) }
                composable("about") { AboutScreen(onBack = { nav.popBackStack() }) }
                composable("tool/{id}") { e ->
                    ToolRoute(e.arguments?.getString("id") ?: "", onBack = { nav.popBackStack() })
                }
            }
        }
    }
}

@Composable
private fun ToolRoute(id: String, onBack: () -> Unit) {
    val app = LocalApp.current
    LaunchedEffect(id) { app.markToolUsed(id) }
    val tool = Tools.byId(id)
    when {
        tool == null -> Screen(title = "ICT Master", onBack = onBack) {
            EmptyState("?", tr("টুল পাওয়া যায়নি", "Tool not found"), "")
        }
        id == Tools.CONVERTER -> ConverterScreen(onBack)
        id == "gates" -> GatesScreen(onBack)
        id == "boolean" -> BooleanScreen(onBack)
        id == "html" -> HtmlScreen(onBack)
        id == "cprog" -> CProgScreen(onBack)
        else -> {
            val spec = ToolSpecs.forTool(id)
            if (spec != null) GenericToolScreen(tool, spec, onBack)
            else Screen(title = tr(tool.bn, tool.en), onBack = onBack) { EmptyState("?", tr("টুল পাওয়া যায়নি", "Tool not found"), "") }
        }
    }
}
