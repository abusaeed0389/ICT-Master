@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.abusaeed.ictmaster.data.Tools
import com.abusaeed.ictmaster.logic.BooleanAlgebra
import com.abusaeed.ictmaster.logic.CalcResult
import com.abusaeed.ictmaster.logic.Expr
import com.abusaeed.ictmaster.logic.ParseException
import kotlinx.coroutines.delay

private class BoolView(val analysis: CalcResult, val expr: Expr?, val table: BooleanAlgebra.Table?)

private fun analyze(src: String, bn: Boolean): BoolView {
    val analysis = BooleanAlgebra.fullAnalysis(src, bn)
    if (!analysis.ok) return BoolView(analysis, null, null)
    return try {
        val e = BooleanAlgebra.parse(src, bn)
        BoolView(analysis, e, BooleanAlgebra.truthTable(e, bn))
    } catch (ex: ParseException) {
        BoolView(CalcResult.fail(ex.message ?: ""), null, null)
    }
}

private class Law(val bn: String, val en: String, val formula: String, val descBn: String, val descEn: String)

private val LAWS = listOf(
    Law("অভেদ সূত্র", "Identity law", "A + 0 = A     A · 1 = A", "0 যোগ বা 1 গুণ করলে মান অপরিবর্তিত।", "Adding 0 or multiplying by 1 changes nothing."),
    Law("নাল সূত্র", "Null (domination) law", "A + 1 = 1     A · 0 = 0", "1 এর সাথে OR সবসময় 1, 0 এর সাথে AND সবসময় 0।", "OR with 1 is always 1; AND with 0 is always 0."),
    Law("ইডেমপোটেন্ট সূত্র", "Idempotent law", "A + A = A     A · A = A", "একই চলকের পুনরাবৃত্তি মান বদলায় না।", "Repeating the same variable does not change the value."),
    Law("পূরক সূত্র", "Complement law", "A + A′ = 1     A · A′ = 0", "একটি চলক ও তার পূরকের OR সবসময় 1, AND সবসময় 0।", "A variable OR its complement is 1; AND is 0."),
    Law("দ্বি-পূরক সূত্র", "Double negation", "(A′)′ = A", "দুইবার উল্টালে মূল মান ফিরে আসে।", "Inverting twice gives back the original."),
    Law("বিনিময় সূত্র", "Commutative law", "A + B = B + A     A · B = B · A", "চলকের ক্রম বদলালে ফল বদলায় না।", "The order of variables does not matter."),
    Law("সহযোগ সূত্র", "Associative law", "(A + B) + C = A + (B + C)", "গ্রুপিং বদলালে ফল বদলায় না।", "Grouping does not matter."),
    Law("বণ্টন সূত্র", "Distributive law", "A(B + C) = AB + AC     A + BC = (A + B)(A + C)", "একটি অপারেশন অন্যটির ওপর বণ্টিত হয়।", "One operation distributes over the other."),
    Law("শোষণ সূত্র", "Absorption law", "A + AB = A     A(A + B) = A", "বড় পদ ছোট পদকে শোষণ করে নেয়।", "The simpler term absorbs the larger one."),
    Law("ডি মরগানের সূত্র", "De Morgan's laws", "(A + B)′ = A′ · B′     (A · B)′ = A′ + B′", "অপারেটর বদলে যায় (+ ↔ ·) এবং প্রতিটি চলক পূরক হয়।", "Swap the operator (+ ↔ ·) and complement each variable.")
)

private val EXAMPLES = listOf("A + AB", "(A·B)′", "AB + A′C + BC", "A ⊕ B", "A(A + B)", "A·A′ + B")

@Composable
fun BooleanScreen(onBack: () -> Unit) {
    val app = LocalApp.current
    val bn = LocalBangla.current
    val tick = rememberHaptics()
    val pending = remember { app.pendingToolInput.also { app.pendingToolInput = null } }
    var src by rememberSaveable { mutableStateOf(pending?.first ?: "") }
    val view = remember(src, bn) { if (src.isBlank()) null else analyze(src, bn) }
    val env = remember { mutableStateMapOf<Char, Boolean>() }

    LaunchedEffect(src) {
        if (src.isNotBlank()) {
            delay(1200)
            val r = BooleanAlgebra.fullAnalysis(src, true)
            if (r.ok) app.addHistory("boolean", "", src, r.output)
        }
    }

    Screen(title = tr("বুলিয়ান অ্যালজেবরা", "Boolean Algebra"), onBack = onBack, tool = Tools.byId("boolean")) {
        AppCard(container = MaterialTheme.colorScheme.tertiaryContainer) {
            Text(
                tr(
                    "A, B, C ... চলক ও + (OR), · বা পাশাপাশি লেখা (AND), ′ বা ! (NOT), ⊕ (XOR) ব্যবহার করুন। যেমন: AB + A′C। AND, OR, NOT, XOR শব্দও চলবে।",
                    "Use variables A, B, C ... with + (OR), · or adjacency (AND), ′ or ! (NOT), ⊕ (XOR). Example: AB + A′C. The words AND, OR, NOT, XOR also work."
                ),
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onTertiaryContainer
            )
        }

        InputField(
            value = src, onChange = { src = it.take(200) },
            label = tr("বুলিয়ান এক্সপ্রেশন", "Boolean expression"),
            keyboard = KeyboardType.Ascii,
            error = if (view != null && !view.analysis.ok) view.analysis.error else null
        )

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (s in listOf("A", "B", "C", "D", "+", "·", "′", "⊕", "(", ")")) {
                FilledTonalButton(onClick = { src += s; tick() }, modifier = Modifier.widthIn(min = 48.dp).heightIn(min = 48.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp)) { Text(s) }
            }
            FilledTonalButton(onClick = { src = src.dropLast(1); tick() }, modifier = Modifier.heightIn(min = 48.dp)) { Text("⌫") }
        }
        ScrollChips(EXAMPLES, -1) { src = EXAMPLES[it]; tick() }

        if (view != null && view.analysis.ok && view.table != null && view.expr != null) {
            val table = view.table
            ResultCard(output = view.analysis.output, note = tr("সরলীকৃত রূপ (Sum of Products)", "Simplified form (Sum of Products)"))

            // evaluate with chosen values
            if (table.vars.isNotEmpty()) {
                val values = table.vars.associateWith { env[it] == true }
                val value = view.expr.eval(values)
                AppCard {
                    Text(tr("মান নির্ণয়", "Evaluate"), style = MaterialTheme.typography.titleMedium)
                    Text(tr("চলকের মান বেছে নিন:", "Choose the variable values:"), style = MaterialTheme.typography.bodyMedium)
                    table.vars.forEach { v ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("$v = ${if (env[v] == true) 1 else 0}", Modifier.weight(1f), fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyLarge)
                            Switch(checked = env[v] == true, onCheckedChange = { env[v] = it; tick() })
                        }
                    }
                    Text(tr("ফলাফল F = ${if (value) 1 else 0}", "Result F = ${if (value) 1 else 0}"), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.tertiary)
                }
                val hi = table.vars.fold(0) { acc, v -> acc * 2 + (if (env[v] == true) 1 else 0) }
                AppCard {
                    Text(tr("সত্যক সারণি", "Truth table"), style = MaterialTheme.typography.titleMedium)
                    TruthTable(table.vars.map { it.toString() } + "F", table.rows.map { r -> r.first.map { it.toString() } + r.second.toString() }, highlight = hi)
                }
            } else {
                AppCard { Text(tr("এই এক্সপ্রেশনে কোনো চলক নেই; মান = ${view.analysis.output}", "No variables in this expression; value = ${view.analysis.output}")) }
            }
            StepsCard(view.analysis.steps)
        }

        LawsCard()
    }
}

@Composable
private fun LawsCard() {
    var open by rememberSaveable { mutableStateOf(false) }
    AppCard {
        Text(tr("বুলিয়ান অ্যালজেবরার মূল সূত্রসমূহ", "Basic Boolean laws"), style = MaterialTheme.typography.titleMedium)
        FilledTonalButton(onClick = { open = !open }) { Text(if (open) tr("লুকান", "Hide") else tr("সূত্রগুলো দেখুন", "Show laws")) }
        if (open) {
            LAWS.forEach { l ->
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(tr(l.bn, l.en), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                    SelectionContainer { Text(l.formula, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium) }
                    Text(tr(l.descBn, l.descEn), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
