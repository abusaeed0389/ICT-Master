@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.clickable
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.abusaeed.ictmaster.data.Tools

private class CExample(val bn: String, val en: String, val code: String, val output: String, val expBn: String, val expEn: String)

private val C_EXAMPLES = listOf(
    CExample("Hello World", "Hello World", """
        #include <stdio.h>

        int main() {
            printf("Hello, ICT!\n");
            return 0;
        }
    """.trimIndent(), "Hello, ICT!",
        "#include <stdio.h> ইনপুট/আউটপুট ফাংশনের জন্য। প্রোগ্রাম main() থেকে শুরু হয় এবং printf() পর্দায় লেখা দেখায়। \\n নতুন লাইন তৈরি করে।",
        "#include <stdio.h> provides input/output functions. The program starts at main() and printf() prints text. \\n starts a new line."),
    CExample("দুটি সংখ্যার যোগফল", "Sum of two numbers", """
        #include <stdio.h>

        int main() {
            int a = 15, b = 27, sum;
            sum = a + b;
            printf("Sum = %d\n", sum);
            return 0;
        }
    """.trimIndent(), "Sum = 42",
        "int পূর্ণসংখ্যার ভেরিয়েবল। %d দিয়ে পূর্ণসংখ্যা প্রিন্ট করা হয়।",
        "int declares integer variables. %d prints an integer."),
    CExample("জোড় না বিজোড়", "Even or odd", """
        #include <stdio.h>

        int main() {
            int n = 7;
            if (n % 2 == 0)
                printf("%d is even\n", n);
            else
                printf("%d is odd\n", n);
            return 0;
        }
    """.trimIndent(), "7 is odd",
        "% অপারেটর ভাগশেষ দেয়। 7 % 2 = 1, তাই সংখ্যাটি বিজোড়।",
        "The % operator gives the remainder. 7 % 2 = 1, so the number is odd."),
    CExample("তিনটি সংখ্যার মধ্যে বড়টি", "Largest of three", """
        #include <stdio.h>

        int main() {
            int a = 12, b = 45, c = 30, max;
            max = a;
            if (b > max) max = b;
            if (c > max) max = c;
            printf("Largest = %d\n", max);
            return 0;
        }
    """.trimIndent(), "Largest = 45",
        "প্রথমে a কে সবচেয়ে বড় ধরা হয়, তারপর b ও c এর সাথে তুলনা করে max আপডেট করা হয়।",
        "Assume a is the largest, then compare with b and c and update max."),
    CExample("ফ্যাক্টোরিয়াল (for লুপ)", "Factorial (for loop)", """
        #include <stdio.h>

        int main() {
            int n = 5, f = 1, i;
            for (i = 1; i <= n; i++) {
                f = f * i;
            }
            printf("Factorial of %d = %d\n", n, f);
            return 0;
        }
    """.trimIndent(), "Factorial of 5 = 120",
        "1 × 2 × 3 × 4 × 5 = 120। for লুপ i = 1 থেকে n পর্যন্ত গুণ করে।",
        "1 × 2 × 3 × 4 × 5 = 120. The for loop multiplies from i = 1 to n."),
    CExample("নামতা (5 এর ঘরের নামতা)", "Multiplication table of 5", """
        #include <stdio.h>

        int main() {
            int i;
            for (i = 1; i <= 5; i++) {
                printf("5 x %d = %d\n", i, 5 * i);
            }
            return 0;
        }
    """.trimIndent(), "5 x 1 = 5\n5 x 2 = 10\n5 x 3 = 15\n5 x 4 = 20\n5 x 5 = 25",
        "লুপের প্রতিবার i এর মান বাড়ে এবং একটি লাইন প্রিন্ট হয়।",
        "Each iteration increases i and prints one line."),
    CExample("ডেসিমাল থেকে বাইনারি", "Decimal to binary", """
        #include <stdio.h>

        int main() {
            int n = 13, bits[32], i = 0, j;
            while (n > 0) {
                bits[i] = n % 2;
                n = n / 2;
                i++;
            }
            printf("Binary = ");
            for (j = i - 1; j >= 0; j--)
                printf("%d", bits[j]);
            printf("\n");
            return 0;
        }
    """.trimIndent(), "Binary = 1101",
        "বারবার 2 দিয়ে ভাগ করে ভাগশেষ জমানো হয়, তারপর উল্টো ক্রমে প্রিন্ট করা হয় (13 → 1101)।",
        "Divide by 2 repeatedly and store remainders, then print them in reverse (13 → 1101)."),
    CExample("লিপ ইয়ার", "Leap year", """
        #include <stdio.h>

        int main() {
            int year = 2024;
            if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
                printf("%d is a leap year\n", year);
            else
                printf("%d is not a leap year\n", year);
            return 0;
        }
    """.trimIndent(), "2024 is a leap year",
        "৪ দিয়ে বিভাজ্য কিন্তু ১০০ দিয়ে নয়, অথবা ৪০০ দিয়ে বিভাজ্য হলে লিপ ইয়ার।",
        "A year divisible by 4 but not by 100, or divisible by 400, is a leap year."),
    CExample("অ্যারের সংখ্যার যোগফল", "Sum of array elements", """
        #include <stdio.h>

        int main() {
            int arr[5] = {2, 4, 6, 8, 10};
            int i, sum = 0;
            for (i = 0; i < 5; i++)
                sum += arr[i];
            printf("Sum = %d\n", sum);
            return 0;
        }
    """.trimIndent(), "Sum = 30",
        "অ্যারের ইনডেক্স 0 থেকে শুরু হয়। sum += arr[i] মানে sum = sum + arr[i]।",
        "Array indexes start at 0. sum += arr[i] means sum = sum + arr[i]."),
    CExample("মৌলিক সংখ্যা যাচাই", "Prime number check", """
        #include <stdio.h>

        int main() {
            int n = 17, i, prime = 1;
            for (i = 2; i < n; i++) {
                if (n % i == 0) {
                    prime = 0;
                    break;
                }
            }
            if (n > 1 && prime)
                printf("%d is prime\n", n);
            else
                printf("%d is not prime\n", n);
            return 0;
        }
    """.trimIndent(), "17 is prime",
        "2 থেকে n-1 পর্যন্ত কোনো সংখ্যা দিয়ে ভাগ গেলে সংখ্যাটি মৌলিক নয়।",
        "If any number from 2 to n-1 divides n, then n is not prime."),
    CExample("দুটি ভেরিয়েবলের মান অদলবদল", "Swap two variables", """
        #include <stdio.h>

        int main() {
            int a = 5, b = 9, temp;
            temp = a;
            a = b;
            b = temp;
            printf("After swap: a = %d, b = %d\n", a, b);
            return 0;
        }
    """.trimIndent(), "After swap: a = 9, b = 5",
        "temp নামের একটি অস্থায়ী ভেরিয়েবল ব্যবহার করে মান বদলানো হয়।",
        "A temporary variable named temp is used to exchange the values.")
)

@Composable
fun CProgScreen(onBack: () -> Unit) {
    var open by rememberSaveable { mutableIntStateOf(0) }
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val tick = rememberHaptics()
    val copied = tr("কোড কপি করা হয়েছে", "Code copied")

    Screen(title = tr("C প্রোগ্রামিং উদাহরণ", "C Programming Examples"), onBack = onBack, tool = Tools.byId("cprog")) {
        AppCard(container = MaterialTheme.colorScheme.tertiaryContainer) {
            Text(
                tr("HSC ICT-এর বেসিক C প্রোগ্রাম। প্রতিটি উদাহরণে কোড, আউটপুট ও ব্যাখ্যা আছে। কোড কপি করে কম্পাইলারে চালাতে পারেন।",
                    "Basic C programs for HSC ICT. Every example has code, output and explanation. Copy the code and run it in any C compiler."),
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onTertiaryContainer
            )
        }
        C_EXAMPLES.forEachIndexed { i, ex ->
            val isOpen = open == i
            AppCard {
                Row(
                    Modifier.fillMaxWidth().clickable(role = Role.Button) { open = if (isOpen) -1 else i; tick() },
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    GlyphBadge("${i + 1}", 36.dp)
                    Text(tr(ex.bn, ex.en), Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    Icon(if (isOpen) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown, contentDescription = null)
                }
                if (isOpen) {
                    MonoBlock(ex.code)
                    Text(tr("আউটপুট", "Output"), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.tertiary)
                    MonoBlock(ex.output)
                    Text(tr(ex.expBn, ex.expEn), style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = { clipboard.setText(AnnotatedString(ex.code)); tick(); toast(ctx, copied) }) { Text(tr("কোড কপি", "Copy code")) }
                }
            }
        }
    }
}
