@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abusaeed.ictmaster.data.ToolDef

const val DEV_NAME = "Abu Saeed"
const val DEV_CREDIT = "Developed by Abu Saeed"
const val DEV_URL = "https://isaeed.netlify.app"
const val APP_VERSION = "2.0"

fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "No browser found", Toast.LENGTH_SHORT).show()
    }
}

fun toast(context: Context, msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

/** Light haptic tick, only when enabled in Settings. */
@Composable
fun rememberHaptics(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    val app = LocalApp.current
    return remember(haptic, app) { { if (app.haptic) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) } }
}

/** Clickable developer credit. Opens exactly https://isaeed.netlify.app in the default browser. */
@Composable
fun DeveloperCredit(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val label = tr("ডেভেলপারের পোর্টফোলিও ওয়েবসাইট খুলুন", "Open the developer's portfolio website")
    Box(
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClickLabel = label, role = Role.Button) { openUrl(ctx, DEV_URL) }
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .semantics { contentDescription = "$DEV_CREDIT. $label" },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = DEV_CREDIT,
            color = MaterialTheme.colorScheme.tertiary,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            textDecoration = TextDecoration.Underline
        )
    }
}

@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    container: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    val colors = CardDefaults.cardColors(containerColor = container)
    val border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    if (onClick != null) {
        Card(onClick = onClick, modifier = modifier.fillMaxWidth(), shape = shape, colors = colors, border = border) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
        }
    } else {
        Card(modifier = modifier.fillMaxWidth(), shape = shape, colors = colors, border = border) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier.padding(top = 6.dp), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground)
}

@Composable
fun GlyphBadge(glyph: String, size: Dp = 44.dp, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.3f))
            .background(Brush.linearGradient(listOf(Blue, Cyan))),
        contentAlignment = Alignment.Center
    ) {
        Text(
            glyph, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, textAlign = TextAlign.Center,
            fontSize = (size.value * (if (glyph.length > 2) 0.25f else 0.38f)).sp, lineHeight = (size.value * 0.5f).sp
        )
    }
}

@Composable
fun ToolRow(tool: ToolDef, favorite: Boolean, onToggleFav: (() -> Unit)?, onClick: () -> Unit) {
    AppCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            GlyphBadge(tool.glyph, 48.dp)
            Column(Modifier.weight(1f)) {
                Text(tr(tool.bn, tool.en), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                Text(tr(tool.descBn, tool.descEn), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (onToggleFav != null) {
                IconButton(onClick = onToggleFav) {
                    Icon(
                        if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = if (favorite) tr("প্রিয় থেকে সরান", "Remove from favorites") else tr("প্রিয় তালিকায় যোগ করুন", "Add to favorites"),
                        tint = if (favorite) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.outline
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyState(glyph: String, title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(vertical = 32.dp, horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        GlyphBadge(glyph, 72.dp)
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
fun ErrorLine(text: String) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.error.copy(alpha = 0.12f)).padding(12.dp),
        verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
        Text(text, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun ScrollChips(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        labels.forEachIndexed { i, l ->
            FilterChip(selected = selected == i, onClick = { onSelect(i) }, label = { Text(l) })
        }
    }
}

@Composable
fun InputField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    keyboard: androidx.compose.ui.text.input.KeyboardType,
    modifier: Modifier = Modifier,
    error: String? = null,
    mono: Boolean = true,
    singleLine: Boolean = true,
    placeholder: String? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label) },
        placeholder = if (placeholder != null) ({ Text(placeholder) }) else null,
        singleLine = singleLine,
        isError = error != null,
        supportingText = if (error != null) ({ Text(error) }) else null,
        textStyle = MaterialTheme.typography.bodyLarge.copy(fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default),
        keyboardOptions = KeyboardOptions(keyboardType = keyboard, autoCorrect = false),
        shape = RoundedCornerShape(16.dp),
        trailingIcon = if (value.isNotEmpty()) ({
            IconButton(onClick = { onChange("") }) {
                Icon(Icons.Filled.Clear, contentDescription = tr("ইনপুট মুছুন", "Clear input"))
            }
        }) else null
    )
}

@Composable
fun ResultCard(output: String, note: String = "", actions: @Composable RowScope.() -> Unit = {}) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val tick = rememberHaptics()
    val msg = tr("কপি করা হয়েছে", "Copied to clipboard")
    AppCard(container = MaterialTheme.colorScheme.primaryContainer) {
        Text(tr("ফলাফল", "Result"), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
        SelectionContainer {
            Text(
                output, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 32.sp,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
        if (note.isNotEmpty()) Text(note, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { clipboard.setText(AnnotatedString(output)); tick(); toast(ctx, msg) }) { Text(tr("কপি", "Copy")) }
            actions()
        }
    }
}

@Composable
fun StepsCard(steps: List<String>) {
    var open by rememberSaveable { mutableStateOf(true) }
    AppCard {
        Row(
            Modifier.fillMaxWidth().clickable(role = Role.Button) { open = !open }.heightIn(min = 40.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(tr("ধাপে ধাপে সমাধান", "Step-by-step solution"), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            Icon(if (open) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown, contentDescription = if (open) tr("সংকুচিত করুন", "Collapse") else tr("প্রসারিত করুন", "Expand"))
        }
        if (open) {
            // merge consecutive monospace ('#') lines into one block
            var i = 0
            while (i < steps.size) {
                if (steps[i].startsWith("#")) {
                    val block = StringBuilder()
                    while (i < steps.size && steps[i].startsWith("#")) { if (block.isNotEmpty()) block.append('\n'); block.append(steps[i].drop(1)); i++ }
                    MonoBlock(block.toString())
                } else {
                    Text(steps[i], style = MaterialTheme.typography.bodyMedium)
                    i++
                }
            }
        }
    }
}

@Composable
fun MonoBlock(text: String, modifier: Modifier = Modifier) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Text(
            text, Modifier.horizontalScroll(rememberScrollState()).padding(12.dp),
            fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium, softWrap = false
        )
    }
}

/** Simple truth-table renderer. [highlight] is the row index to emphasise (or -1). */
@Composable
fun TruthTable(headers: List<String>, rows: List<List<String>>, highlight: Int = -1, lastIsOutput: Boolean = true) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
    ) {
        TableRow(headers, header = true, lastIsOutput = lastIsOutput, highlight = false)
        rows.forEachIndexed { i, r -> TableRow(r, header = false, lastIsOutput = lastIsOutput, highlight = i == highlight) }
    }
}

@Composable
private fun TableRow(cells: List<String>, header: Boolean, lastIsOutput: Boolean, highlight: Boolean) {
    val bg = when {
        header -> MaterialTheme.colorScheme.secondaryContainer
        highlight -> MaterialTheme.colorScheme.tertiaryContainer
        else -> Color.Transparent
    }
    Row(Modifier.fillMaxWidth().background(bg).padding(vertical = 8.dp)) {
        cells.forEachIndexed { i, c ->
            val isOut = lastIsOutput && i == cells.lastIndex
            Text(
                c, Modifier.weight(1f), textAlign = TextAlign.Center, fontFamily = FontFamily.Monospace,
                fontWeight = if (header || isOut) FontWeight.Bold else FontWeight.Normal,
                color = if (isOut && !header) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurface,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** Page scaffold used by every screen. [tab] screens live under the bottom navigation bar. */
@Composable
fun Screen(
    title: String,
    onBack: (() -> Unit)? = null,
    tool: ToolDef? = null,
    tab: Boolean = false,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    val app = LocalApp.current
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = if (tab) WindowInsets(0, 0, 0, 0) else WindowInsets.systemBars,
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    if (onBack != null) IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = tr("পিছনে যান", "Back"))
                    }
                },
                actions = {
                    if (tool != null) {
                        val fav = app.favorites.contains(tool.id)
                        IconButton(onClick = { app.toggleFavorite(tool.id) }) {
                            Icon(
                                if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = if (fav) tr("প্রিয় থেকে সরান", "Remove from favorites") else tr("প্রিয় তালিকায় যোগ করুন", "Add to favorites"),
                                tint = if (fav) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    actions()
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).imePadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            content()
            Spacer(Modifier.height(16.dp))
        }
    }
}
