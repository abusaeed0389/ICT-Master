@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import com.abusaeed.ictmaster.data.Tools
import com.abusaeed.ictmaster.logic.NumberSystem
import kotlinx.coroutines.delay

private val PRESETS = listOf(
    10 to 2, 2 to 10, 10 to 8, 8 to 10, 10 to 16, 16 to 10,
    2 to 8, 8 to 2, 2 to 16, 16 to 2, 8 to 16, 16 to 8
)

@Composable
fun ConverterScreen(onBack: () -> Unit) {
    val app = LocalApp.current
    val bn = LocalBangla.current
    val tool = Tools.byId(Tools.CONVERTER)
    val pending = remember { app.pendingConversion.also { app.pendingConversion = null } }
    var from by rememberSaveable { mutableIntStateOf(pending?.first ?: 10) }
    var to by rememberSaveable { mutableIntStateOf(pending?.second ?: 2) }
    var input by rememberSaveable { mutableStateOf(pending?.third ?: "") }
    val tick = rememberHaptics()

    val result = remember(input, from, to, bn) { if (input.isBlank()) null else NumberSystem.convert(input, from, to, bn) }

    // Save to history once the user stops typing.
    LaunchedEffect(input, from, to) {
        if (input.isNotBlank()) {
            delay(1200)
            val r = NumberSystem.convert(input, from, to, true)
            if (r.ok) app.addHistory(Tools.CONVERTER, "", input, r.output, from, to)
        }
    }

    Screen(title = tr("সংখ্যা পদ্ধতি রূপান্তর", "Number System Converter"), onBack = onBack, tool = tool) {
        SectionTitle(tr("দ্রুত রূপান্তর বেছে নিন", "Quick conversions"))
        ScrollChips(
            labels = PRESETS.map { "${NumberSystem.baseName(it.first, bn)} → ${NumberSystem.baseName(it.second, bn)}" },
            selected = PRESETS.indexOf(Pair(from, to)),
            onSelect = { from = PRESETS[it].first; to = PRESETS[it].second; tick() }
        )

        AppCard {
            Text(tr("যে সংখ্যা পদ্ধতি থেকে", "From"), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            ScrollChips(NumberSystem.bases.map { "${NumberSystem.baseName(it, bn)} ($it)" }, NumberSystem.bases.indexOf(from)) { from = NumberSystem.bases[it]; tick() }
            Text(tr("যে সংখ্যা পদ্ধতিতে", "To"), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            ScrollChips(NumberSystem.bases.map { "${NumberSystem.baseName(it, bn)} ($it)" }, NumberSystem.bases.indexOf(to)) { to = NumberSystem.bases[it]; tick() }
        }

        InputField(
            value = input,
            onChange = { input = it.filter { c -> !c.isWhitespace() }.take(NumberSystem.MAX_INPUT_LENGTH) },
            label = tr("${NumberSystem.baseName(from, true)} সংখ্যা লিখুন", "Enter ${NumberSystem.baseName(from, false)} number"),
            keyboard = if (from == 16) KeyboardType.Ascii else KeyboardType.Decimal,
            error = if (result != null && !result.ok) result.error else null,
            placeholder = tr("বৈধ অঙ্ক: ${NumberSystem.validDigits(from)}", "Valid digits: ${NumberSystem.validDigits(from)}")
        )

        if (result != null && result.ok) {
            ResultCard(output = result.output, note = result.note) {
                FilledTonalButton(onClick = { input = result.output; val t = from; from = to; to = t; tick() }) {
                    Text("⇄ " + tr("অদলবদল", "Swap"))
                }
            }
            StepsCard(result.steps)
        } else if (input.isBlank()) {
            AppCard(container = MaterialTheme.colorScheme.tertiaryContainer) {
                Text(tr("কীভাবে ব্যবহার করবেন", "How to use"), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onTertiaryContainer)
                Text(
                    tr(
                        "উপরে বেস নির্বাচন করে সংখ্যা লিখুন। ফলাফল ও ধাপে ধাপে সমাধান সাথে সাথেই দেখা যাবে। ভগ্নাংশ (যেমন 10.625) এবং বড় সংখ্যাও সমর্থিত।",
                        "Pick the bases above and type a number. The result and step-by-step working appear instantly. Fractions (e.g. 10.625) and very large numbers are supported."
                    ),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onTertiaryContainer
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                    TextButton(onClick = { from = 10; to = 2; input = "37.625"; tick() }) { Text(tr("উদাহরণ: 37.625 → বাইনারি", "Example: 37.625 → binary")) }
                }
            }
        }
    }
}
