@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abusaeed.ictmaster.data.Tools
import com.abusaeed.ictmaster.logic.Gate

@Composable
fun GatesScreen(onBack: () -> Unit) {
    val bn = LocalBangla.current
    val tick = rememberHaptics()
    var gi by rememberSaveable { mutableIntStateOf(0) }
    var a by rememberSaveable { mutableIntStateOf(0) }
    var b by rememberSaveable { mutableIntStateOf(0) }
    val gate = Gate.values()[gi]
    val out = gate.eval(a, b)

    Screen(title = tr("লজিক গেট সিমুলেটর", "Logic Gate Simulator"), onBack = onBack, tool = Tools.byId("gates")) {
        ScrollChips(Gate.values().map { it.name }, gi) { gi = it; tick() }

        AppCard {
            Text(
                tr(gate.bnName, gate.enName) + "   ( ${gate.symbol} )",
                style = MaterialTheme.typography.titleMedium
            )
            GateDiagram(gate, a, b, out)

            SwitchRow("A", a == 1) { a = if (it) 1 else 0; tick() }
            if (gate.inputs == 2) SwitchRow("B", b == 1) { b = if (it) 1 else 0; tick() }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier.size(28.dp).clip(CircleShape)
                        .background(if (out == 1) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.outlineVariant)
                )
                Text(
                    tr("আউটপুট Y = $out", "Output Y = $out"),
                    style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Monospace,
                    color = if (out == 1) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurface
                )
            }
        }

        AppCard {
            Text(tr("গেটটি কী করে?", "What does it do?"), style = MaterialTheme.typography.titleMedium)
            Text(gate.explanation(bn), style = MaterialTheme.typography.bodyMedium)
        }

        AppCard {
            Text(tr("সত্যক সারণি (Truth Table)", "Truth Table"), style = MaterialTheme.typography.titleMedium)
            val rows = gate.truthTable()
            if (gate.inputs == 1) {
                TruthTable(listOf("A", "Y"), rows.map { listOf(it.first.toString(), it.third.toString()) }, highlight = a)
            } else {
                TruthTable(listOf("A", "B", "Y"), rows.map { listOf(it.first.toString(), it.second.toString(), it.third.toString()) }, highlight = a * 2 + b)
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            tr("ইনপুট $label = ${if (checked) 1 else 0}", "Input $label = ${if (checked) 1 else 0}"),
            Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium
        )
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Draws the standard logic-gate symbol with wires coloured by their current logic level. */
@Composable
fun GateDiagram(gate: Gate, a: Int, b: Int, out: Int, modifier: Modifier = Modifier) {
    val on = MaterialTheme.colorScheme.tertiary
    val off = MaterialTheme.colorScheme.outline
    val ink = MaterialTheme.colorScheme.onSurface
    val fill = MaterialTheme.colorScheme.surfaceVariant
    val desc = tr("${gate.name} গেটের চিত্র। ইনপুট A = $a" + (if (gate.inputs == 2) ", B = $b" else "") + ", আউটপুট = $out",
        "${gate.name} gate diagram. Input A = $a" + (if (gate.inputs == 2) ", B = $b" else "") + ", output = $out")

    Canvas(modifier.fillMaxWidth().height(150.dp).semantics { contentDescription = desc }) {
        val w = size.width
        val h = size.height
        val bodyH = minOf(h * 0.78f, 110.dp.toPx())
        val bodyW = minOf(w * 0.36f, 150.dp.toPx())
        val bubble = gate == Gate.NOT || gate == Gate.NAND || gate == Gate.NOR || gate == Gate.XNOR
        val r = 7.dp.toPx()
        val left = w / 2f - bodyW / 2f
        val right = w / 2f + bodyW / 2f
        val top = h / 2f - bodyH / 2f
        val bottom = h / 2f + bodyH / 2f
        val midY = h / 2f
        val bodyRight = if (bubble) right - 2f * r else right
        val bw = bodyRight - left

        val path = Path()
        when (gate) {
            Gate.AND, Gate.NAND -> {
                val rad = minOf(bodyH / 2f, bw * 0.55f)
                val straightEnd = bodyRight - rad
                path.moveTo(left, top)
                path.lineTo(straightEnd, top)
                path.arcTo(Rect(straightEnd - rad, top, straightEnd + rad, bottom), -90f, 180f, false)
                path.lineTo(left, bottom)
                path.close()
            }
            Gate.OR, Gate.NOR, Gate.XOR, Gate.XNOR -> {
                val c = left + bw * 0.5f
                path.moveTo(left, top)
                path.quadraticBezierTo(c, top, bodyRight, midY)
                path.quadraticBezierTo(c, bottom, left, bottom)
                path.quadraticBezierTo(left + bw * 0.25f, midY, left, top)
                path.close()
            }
            Gate.NOT -> {
                path.moveTo(left, top + bodyH * 0.1f)
                path.lineTo(bodyRight, midY)
                path.lineTo(left, bottom - bodyH * 0.1f)
                path.close()
            }
        }
        val stroke = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        val wireW = 4.dp.toPx()
        drawPath(path, fill)
        drawPath(path, ink, style = stroke)
        if (gate == Gate.XOR || gate == Gate.XNOR) {
            val extra = Path()
            val x0 = left - bw * 0.07f
            extra.moveTo(x0, top)
            extra.quadraticBezierTo(x0 + bw * 0.25f, midY, x0, bottom)
            drawPath(extra, ink, style = stroke)
        }
        if (bubble) {
            drawCircle(fill, r, Offset(right - r, midY))
            drawCircle(ink, r, Offset(right - r, midY), style = stroke)
        }

        val inEnd = when (gate) {
            Gate.OR, Gate.NOR -> left + bw * 0.1f
            Gate.XOR, Gate.XNOR -> left + bw * 0.03f
            else -> left
        }
        val x0 = w * 0.05f
        val y1 = if (gate.inputs == 1) midY else top + bodyH * 0.28f
        val y2 = top + bodyH * 0.72f
        drawLine(if (a == 1) on else off, Offset(x0, y1), Offset(inEnd, y1), wireW, StrokeCap.Round)
        if (gate.inputs == 2) drawLine(if (b == 1) on else off, Offset(x0, y2), Offset(inEnd, y2), wireW, StrokeCap.Round)
        drawLine(if (out == 1) on else off, Offset(right, midY), Offset(w * 0.95f, midY), wireW, StrokeCap.Round)

        val paint = Paint().apply {
            isAntiAlias = true
            color = ink.toArgb()
            textSize = 14.dp.toPx()
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        drawIntoCanvas { c ->
            val n = c.nativeCanvas
            n.drawText("A=$a", x0, y1 - 8.dp.toPx(), paint)
            if (gate.inputs == 2) n.drawText("B=$b", x0, y2 - 8.dp.toPx(), paint)
            n.drawText("Y=$out", w * 0.95f - 36.dp.toPx(), midY - 10.dp.toPx(), paint)
        }
    }
}
