@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.abusaeed.ictmaster.data.ToolDef
import com.abusaeed.ictmaster.logic.BinaryOps
import com.abusaeed.ictmaster.logic.CalcResult
import kotlinx.coroutines.delay

class FieldSpec(
    val bn: String,
    val en: String,
    val keyboard: KeyboardType,
    val mono: Boolean = true,
    val maxLen: Int = 300
)

class OptionSpec(val labelBn: String, val labelEn: String, val choices: List<Pair<String, String>>, val default: Int = 0)

class GenericSpec(
    val fields: List<FieldSpec>,
    val options: List<OptionSpec> = emptyList(),
    val visibleFields: (List<Int>) -> Int = { fields.size },
    val compute: (inputs: List<String>, picks: List<Int>, bn: Boolean) -> CalcResult,
    val opLabel: (List<Int>) -> String = { "" },
    val infoBn: String,
    val infoEn: String,
    val example: List<String>? = null,
    val extra: (@Composable () -> Unit)? = null
)

@Composable
fun GenericToolScreen(tool: ToolDef, spec: GenericSpec, onBack: () -> Unit) {
    val app = LocalApp.current
    val bn = LocalBangla.current
    val tick = rememberHaptics()
    val pending = remember { app.pendingToolInput.also { app.pendingToolInput = null } }

    val vals: SnapshotStateList<String> = remember {
        mutableStateListOf<String>().apply {
            val saved = pending?.first?.split("\u001F") ?: emptyList()
            for (i in spec.fields.indices) add(saved.getOrElse(i) { "" })
        }
    }
    val picks: SnapshotStateList<Int> = remember {
        mutableStateListOf<Int>().apply {
            val decoded = if (pending != null) listOf(pending.second % 100, pending.second / 100, pending.third) else emptyList()
            for (i in spec.options.indices) add(decoded.getOrElse(i) { spec.options[i].default }.coerceIn(0, spec.options[i].choices.size - 1))
        }
    }

    val visible = spec.visibleFields(picks.toList()).coerceIn(1, spec.fields.size)
    val inputs = vals.take(visible)
    val ready = inputs.all { it.isNotBlank() }
    val key = inputs.joinToString("\u0001") + "|" + picks.joinToString(",") + "|" + bn
    val result: CalcResult? = remember(key) { if (ready) spec.compute(inputs, picks.toList(), bn) else null }

    LaunchedEffect(key) {
        if (ready) {
            delay(1200)
            val r = spec.compute(inputs, picks.toList(), true)
            if (r.ok) app.addHistory(
                tool.id, spec.opLabel(picks.toList()), inputs.joinToString("\u001F"), r.output,
                picks.getOrElse(0) { 0 } + 100 * picks.getOrElse(1) { 0 }, picks.getOrElse(2) { 0 }
            )
        }
    }

    Screen(title = tr(tool.bn, tool.en), onBack = onBack, tool = tool) {
        AppCard(container = MaterialTheme.colorScheme.tertiaryContainer) {
            Text(tr(spec.infoBn, spec.infoEn), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onTertiaryContainer)
        }

        spec.options.forEachIndexed { i, opt ->
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(tr(opt.labelBn, opt.labelEn), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                ScrollChips(opt.choices.map { if (bn) it.first else it.second }, picks[i]) { picks[i] = it; tick() }
            }
        }

        for (i in 0 until visible) {
            val f = spec.fields[i]
            InputField(
                value = vals[i], onChange = { vals[i] = it.take(f.maxLen) },
                label = tr(f.bn, f.en), keyboard = f.keyboard, mono = f.mono
            )
        }

        if (spec.example != null) {
            FilledTonalButton(onClick = { spec.example.forEachIndexed { i, s -> if (i < vals.size) vals[i] = s }; tick() }) {
                Text(tr("উদাহরণ ব্যবহার করুন", "Use an example"))
            }
        }

        if (result != null) {
            if (result.ok) {
                ResultCard(output = result.output, note = result.note)
                StepsCard(result.steps)
            } else ErrorLine(result.error)
        }
        spec.extra?.invoke()
    }
}

@Composable
fun AsciiTable() {
    var open by rememberSaveable { mutableStateOf(false) }
    AppCard {
        Text(tr("ASCII টেবিল (32–126)", "ASCII table (32–126)"), style = MaterialTheme.typography.titleMedium)
        Text(
            tr(
                "স্ট্যান্ডার্ড ASCII ৭ বিটের, মোট 128টি অক্ষর (0–127)। 0–31 কন্ট্রোল ক্যারেক্টার; 32–126 দৃশ্যমান অক্ষর।",
                "Standard ASCII is 7-bit with 128 characters (0–127). 0–31 are control characters; 32–126 are printable."
            ),
            style = MaterialTheme.typography.bodyMedium
        )
        FilledTonalButton(onClick = { open = !open }) { Text(if (open) tr("টেবিল লুকান", "Hide table") else tr("টেবিল দেখুন", "Show table")) }
        if (open) {
            val sb = StringBuilder()
            var c = 32
            while (c <= 126) {
                val line = (0 until 4).mapNotNull { k ->
                    val code = c + k
                    if (code > 126) null else "%3d %-2s".format(code, if (code == 32) "SP" else code.toChar().toString())
                }.joinToString("   ")
                sb.append(line).append('\n')
                c += 4
            }
            MonoBlock(sb.toString().trimEnd())
        }
    }
}

private val OPS = listOf("+", "−", "×", "÷")

private fun baseCalcSpec(base: Int): GenericSpec {
    val name = com.abusaeed.ictmaster.logic.NumberSystem.baseName(base, true)
    val nameEn = com.abusaeed.ictmaster.logic.NumberSystem.baseName(base, false)
    val kb = if (base == 16) KeyboardType.Ascii else KeyboardType.Number
    return GenericSpec(
        fields = listOf(
            FieldSpec("প্রথম সংখ্যা A ($name)", "First number A ($nameEn)", kb),
            FieldSpec("দ্বিতীয় সংখ্যা B ($name)", "Second number B ($nameEn)", kb)
        ),
        options = listOf(OptionSpec("অপারেশন", "Operation", OPS.map { it to it })),
        compute = { v, p, bn -> BinaryOps.baseCalc(v[0], v[1], OPS[p[0]], base, bn) },
        opLabel = { p -> "${OPS[p[0]]} (base $base)" },
        infoBn = "$name সংখ্যায় যোগ, বিয়োগ, গুণ ও ভাগ করুন। ভাগের ক্ষেত্রে ভাগফল ও ভাগশেষ দেখানো হয়।",
        infoEn = "Add, subtract, multiply and divide $nameEn numbers. Division shows quotient and remainder.",
        example = if (base == 16) listOf("1A", "F") else listOf("1011", "101")
    )
}

object ToolSpecs {
    private val bin = KeyboardType.Number

    private fun twoBin(
        infoBn: String, infoEn: String, ex: List<String>, c: (String, String, Boolean) -> CalcResult
    ) = GenericSpec(
        fields = listOf(
            FieldSpec("প্রথম বাইনারি সংখ্যা (A)", "First binary number (A)", bin),
            FieldSpec("দ্বিতীয় বাইনারি সংখ্যা (B)", "Second binary number (B)", bin)
        ),
        compute = { v, _, bn -> c(v[0], v[1], bn) },
        infoBn = infoBn, infoEn = infoEn, example = ex
    )

    private fun oneBin(
        infoBn: String, infoEn: String, ex: String, labelBn: String = "বাইনারি সংখ্যা", labelEn: String = "Binary number",
        c: (String, Boolean) -> CalcResult
    ) = GenericSpec(
        fields = listOf(FieldSpec(labelBn, labelEn, bin)),
        compute = { v, _, bn -> c(v[0], bn) },
        infoBn = infoBn, infoEn = infoEn, example = listOf(ex)
    )

    fun forTool(id: String): GenericSpec? = when (id) {
        "bin_add" -> twoBin("দুটি বাইনারি সংখ্যা যোগ করুন। ক্যারি সহ কলাম ধরে ধরে সমাধান দেখানো হবে।", "Add two binary numbers. A column-by-column solution with carries is shown.", listOf("1011", "110")) { a, b, bn -> BinaryOps.add(a, b, bn) }
        "bin_sub" -> twoBin("A − B হিসাব করুন। 2's কমপ্লিমেন্ট পদ্ধতিতে ধাপে ধাপে সমাধান দেখানো হবে।", "Compute A − B using the 2's complement method with full steps.", listOf("1010", "11")) { a, b, bn -> BinaryOps.subtract(a, b, bn) }
        "bin_mul" -> twoBin("দুটি বাইনারি সংখ্যা গুণ করুন। আংশিক গুণফল সহ দেখানো হবে।", "Multiply two binary numbers, with partial products.", listOf("101", "11")) { a, b, bn -> BinaryOps.multiply(a, b, bn) }
        "bin_div" -> twoBin("A ÷ B হিসাব করুন। ভাগফল ও ভাগশেষ দেখানো হবে।", "Compute A ÷ B. The quotient and remainder are shown.", listOf("1101", "10")) { a, b, bn -> BinaryOps.divide(a, b, bn) }
        "ones" -> oneBin("প্রতিটি বিট উল্টে (0 ↔ 1) 1's কমপ্লিমেন্ট পাওয়া যায়।", "Invert every bit (0 ↔ 1) to get the 1's complement.", "10110") { a, bn -> BinaryOps.onesComplement(a, bn) }
        "twos" -> oneBin("2's কমপ্লিমেন্ট = 1's কমপ্লিমেন্ট + 1। ইনপুটের বিট সংখ্যাই ফলাফলের বিট সংখ্যা।", "2's complement = 1's complement + 1. The result has the same number of bits as the input.", "10110") { a, bn -> BinaryOps.twosComplement(a, bn) }
        "bin2bcd" -> oneBin("বাইনারিকে প্রথমে ডেসিমালে নিয়ে প্রতিটি অঙ্ক ৪ বিটে লিখে BCD (8421) পাওয়া যায়।", "Convert binary to decimal, then write each digit in 4 bits to get 8421 BCD.", "11001") { a, bn -> BinaryOps.binaryToBcd(a, bn) }
        "bcd2bin" -> oneBin("BCD কোড (৪ বিটের গ্রুপ, স্পেস দিতে পারেন) থেকে বাইনারি সংখ্যা পান।", "Convert a BCD code (4-bit groups, spaces allowed) to a binary number.", "0010 0101", "BCD কোড", "BCD code") { a, bn -> BinaryOps.bcdToBinary(a, bn) }
        "bitwise" -> {
            val ops = listOf("AND", "OR", "XOR", "NOT")
            GenericSpec(
                fields = listOf(
                    FieldSpec("প্রথম বাইনারি সংখ্যা (A)", "First binary number (A)", bin),
                    FieldSpec("দ্বিতীয় বাইনারি সংখ্যা (B)", "Second binary number (B)", bin)
                ),
                options = listOf(OptionSpec("অপারেশন", "Operation", ops.map { it to it })),
                visibleFields = { p -> if (p[0] == 3) 1 else 2 },
                compute = { v, p, bn -> BinaryOps.bitwise(ops[p[0]], v[0], v.getOrElse(1) { "" }, bn) },
                opLabel = { p -> ops[p[0]] },
                infoBn = "দুটি বাইনারি সংখ্যার প্রতিটি বিটে AND, OR, XOR এবং একটি সংখ্যায় NOT প্রয়োগ করুন।",
                infoEn = "Apply AND, OR, XOR bit by bit on two binary numbers, or NOT on one number.",
                example = listOf("1100", "1010")
            )
        }
        "gray" -> GenericSpec(
            fields = listOf(FieldSpec("ইনপুট কোড", "Input code", bin)),
            options = listOf(OptionSpec("রূপান্তরের ধরন", "Conversion", listOf("বাইনারি → গ্রে" to "Binary → Gray", "গ্রে → বাইনারি" to "Gray → Binary"))),
            compute = { v, p, bn -> if (p[0] == 0) BinaryOps.binaryToGray(v[0], bn) else BinaryOps.grayToBinary(v[0], bn) },
            opLabel = { p -> if (p[0] == 0) "Binary → Gray" else "Gray → Binary" },
            infoBn = "গ্রে কোডে পাশাপাশি দুটি সংখ্যার মধ্যে কেবল একটি বিটের পার্থক্য থাকে।",
            infoEn = "In Gray code only one bit changes between consecutive numbers.",
            example = listOf("1011")
        )
        "ascii" -> GenericSpec(
            fields = listOf(FieldSpec("টেক্সট বা কোড", "Text or codes", KeyboardType.Text, mono = false)),
            options = listOf(
                OptionSpec("রূপান্তরের ধরন", "Conversion", listOf("টেক্সট → কোড" to "Text → Code", "কোড → টেক্সট" to "Code → Text")),
                OptionSpec("কোডের বেস (কোড → টেক্সটের জন্য)", "Code base (for Code → Text)", listOf("ডেসিমাল" to "Decimal", "হেক্সা" to "Hex", "বাইনারি" to "Binary"))
            ),
            compute = { v, p, bn ->
                if (p[0] == 0) BinaryOps.textToAscii(v[0], bn)
                else BinaryOps.asciiToText(v[0], when (p[1]) { 0 -> 10; 1 -> 16; else -> 2 }, bn)
            },
            opLabel = { p -> if (p[0] == 0) "Text → ASCII" else "ASCII → Text" },
            infoBn = "অক্ষরের ASCII কোড দেখুন, অথবা কোড থেকে অক্ষর বের করুন (একাধিক কোড স্পেস দিয়ে লিখুন)।",
            infoEn = "See the ASCII code of characters, or decode codes back to text (separate codes with spaces).",
            example = listOf("ICT 2.0"),
            extra = { AsciiTable() }
        )
        "hexcalc" -> baseCalcSpec(16)
        "bincalc" -> baseCalcSpec(2)
        "units" -> {
            val names = BinaryOps.unitNames
            GenericSpec(
                fields = listOf(FieldSpec("মান", "Value", KeyboardType.Decimal)),
                options = listOf(
                    OptionSpec("যে ইউনিট থেকে", "From unit", names.map { it to it }, 2),
                    OptionSpec("যে ইউনিটে", "To unit", names.map { it to it }, 3),
                    OptionSpec("গণনার ভিত্তি", "Convention", listOf("1024 (কম্পিউটার)" to "1024 (computing)", "1000 (দশমিক)" to "1000 (decimal)"))
                ),
                compute = { v, p, bn -> BinaryOps.convertUnit(v[0], p[0], p[1], p[2] == 0, bn) },
                opLabel = { p -> "${names[p[0]]} → ${names[p[1]]}" },
                infoBn = "১ বাইট = ৮ বিট। HSC-তে সাধারণত ১ KB = ১০২৪ বাইট ধরা হয়।",
                infoEn = "1 byte = 8 bits. In HSC ICT, 1 KB is normally taken as 1024 bytes.",
                example = listOf("2048")
            )
        }
        else -> null
    }
}
