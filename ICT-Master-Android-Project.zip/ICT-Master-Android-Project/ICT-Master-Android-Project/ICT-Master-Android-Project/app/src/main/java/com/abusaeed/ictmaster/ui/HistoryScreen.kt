@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.abusaeed.ictmaster.data.HistoryItem
import com.abusaeed.ictmaster.data.Tools
import com.abusaeed.ictmaster.logic.NumberSystem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatDate(ts: Long, bangla: Boolean): String = try {
    SimpleDateFormat("dd MMM yyyy, hh:mm a", if (bangla) Locale("bn", "BD") else Locale.ENGLISH).format(Date(ts))
} catch (e: Exception) { ts.toString() }

@Composable
fun HistoryScreen(onOpen: (String) -> Unit) {
    val app = LocalApp.current
    val bn = LocalBangla.current
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val tick = rememberHaptics()
    var confirm by remember { mutableStateOf(false) }
    val copied = tr("কপি করা হয়েছে", "Copied to clipboard")

    Screen(
        title = tr("ইতিহাস", "History"), tab = true,
        actions = {
            if (app.history.isNotEmpty()) TextButton(onClick = { confirm = true }) { Text(tr("সব মুছুন", "Clear all")) }
        }
    ) {
        if (app.history.isEmpty()) {
            EmptyState("⏱", tr("ইতিহাস খালি", "History is empty"), tr("আপনার রূপান্তর ও হিসাবগুলো এখানে সংরক্ষিত হবে এবং ফোনেই থাকবে।", "Your conversions and calculations are saved here, on your device only."))
        } else {
            app.history.forEach { h ->
                HistoryCard(h, bn,
                    onOpen = {
                        if (h.toolId == Tools.CONVERTER) app.pendingConversion = Triple(h.p1, h.p2, h.input)
                        else app.pendingToolInput = Triple(h.input, h.p1, h.p2)
                        tick(); onOpen(h.toolId)
                    },
                    onCopy = { clipboard.setText(AnnotatedString(h.output)); tick(); toast(ctx, copied) },
                    onDelete = { app.deleteHistory(h.id); tick() }
                )
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(tr("সব ইতিহাস মুছবেন?", "Clear all history?")) },
            text = { Text(tr("এই কাজটি ফিরিয়ে নেওয়া যাবে না।", "This cannot be undone.")) },
            confirmButton = { TextButton(onClick = { app.clearHistory(); confirm = false }) { Text(tr("মুছুন", "Delete")) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text(tr("বাতিল", "Cancel")) } }
        )
    }
}

@Composable
private fun HistoryCard(h: HistoryItem, bn: Boolean, onOpen: () -> Unit, onCopy: () -> Unit, onDelete: () -> Unit) {
    val tool = Tools.byId(h.toolId)
    val title = if (h.toolId == Tools.CONVERTER) "${NumberSystem.baseName(h.p1, bn)} → ${NumberSystem.baseName(h.p2, bn)}"
    else (if (tool != null) (if (bn) tool.bn else tool.en) else h.toolId) + (if (h.label.isNotEmpty()) " · ${h.label}" else "")
    AppCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Text(formatDate(h.ts, bn), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = tr("এই রেকর্ড মুছুন", "Delete this record"), tint = MaterialTheme.colorScheme.error)
            }
        }
        Text(tr("ইনপুট", "Input"), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(h.input.replace("\u001F", "  ,  "), fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium)
        Text(tr("আউটপুট", "Output"), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(h.output, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.tertiary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = onOpen) { Text(tr("খুলুন", "Open")) }
            TextButton(onClick = onCopy) { Text(tr("কপি", "Copy")) }
        }
    }
}
