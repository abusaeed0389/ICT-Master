@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abusaeed.ictmaster.data.Category
import com.abusaeed.ictmaster.data.Tools
import com.abusaeed.ictmaster.logic.NumberSystem
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpenTool: (String) -> Unit, onTab: (String) -> Unit, onSearch: () -> Unit) {
    val app = LocalApp.current
    val bn = LocalBangla.current
    val tick = rememberHaptics()

    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greeting = when (hour) {
        in 5..11 -> tr("শুভ সকাল", "Good morning")
        in 12..14 -> tr("শুভ দুপুর", "Good afternoon")
        in 15..17 -> tr("শুভ বিকেল", "Good afternoon")
        in 18..19 -> tr("শুভ সন্ধ্যা", "Good evening")
        else -> tr("শুভ রাত্রি", "Good night")
    }
    val welcome = if (app.userName.isBlank()) "$greeting!" else "$greeting, ${app.userName}!"

    Screen(title = "ICT Master", tab = true) {
        // Header
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(Navy, Blue, Cyan))).padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                GlyphBadge("ICT", 64.dp)
                Column(Modifier.weight(1f)) {
                    Text(welcome, color = Color.White, style = MaterialTheme.typography.titleLarge)
                    Text(
                        tr("HSC ICT শেখার স্মার্ট সঙ্গী • সংস্করণ $APP_VERSION", "Your smart HSC ICT companion • v$APP_VERSION"),
                        color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        // Search bar
        Row(
            Modifier.fillMaxWidth().heightIn(min = 56.dp).clip(RoundedCornerShape(28.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable(onClickLabel = tr("টুল ও বিষয় খুঁজুন", "Search tools and topics"), role = Role.Button) { onSearch() }
                .padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(Icons.Filled.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(tr("টুল ও বিষয় খুঁজুন…", "Search tools and topics…"), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // Number conversion shortcut
        AppCard(container = MaterialTheme.colorScheme.primaryContainer) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GlyphBadge("⇄", 44.dp)
                Column(Modifier.weight(1f)) {
                    Text(tr("সংখ্যা পদ্ধতি রূপান্তর", "Number System Converter"), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text(tr("বাইনারি • অক্টাল • ডেসিমাল • হেক্সা", "Binary • Octal • Decimal • Hex"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(10 to 2, 2 to 10, 10 to 16, 16 to 10, 2 to 8, 2 to 16).forEach { (f, t) ->
                    AssistChip(
                        onClick = { app.pendingConversion = Triple(f, t, ""); tick(); onOpenTool(Tools.CONVERTER) },
                        label = { Text("${NumberSystem.baseName(f, bn)} → ${NumberSystem.baseName(t, bn)}") }
                    )
                }
            }
        }

        // Popular tools
        SectionTitle(tr("জনপ্রিয় টুলস", "Popular tools"))
        val popular = listOf("converter", "gates", "boolean", "twos", "bin_add", "ascii").mapNotNull { Tools.byId(it) }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            popular.forEach { t ->
                AppCard(Modifier.width(150.dp), onClick = { onOpenTool(t.id) }) {
                    GlyphBadge(t.glyph, 44.dp)
                    Text(tr(t.bn, t.en), style = MaterialTheme.typography.titleSmall, maxLines = 2, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // Recent tools
        val recents = app.recentTools.mapNotNull { Tools.byId(it) }
        if (recents.isNotEmpty()) {
            SectionTitle(tr("সম্প্রতি ব্যবহৃত", "Recently used"))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                recents.forEach { t -> AssistChip(onClick = { onOpenTool(t.id) }, label = { Text(tr(t.bn, t.en)) }) }
            }
        }

        // Favourites
        val favs = app.favorites.mapNotNull { Tools.byId(it) }
        if (favs.isNotEmpty()) {
            SectionTitle(tr("প্রিয় টুলস", "Favorite tools"))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                favs.forEach { t -> AssistChip(onClick = { onOpenTool(t.id) }, label = { Text(tr(t.bn, t.en)) }) }
            }
        }

        // Daily tip
        val tip = app.tipOfDay()
        AppCard(container = MaterialTheme.colorScheme.tertiaryContainer) {
            Text(tr("💡 আজকের ICT টিপ", "💡 Today's ICT tip"), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onTertiaryContainer)
            Text(tr(tip.first, tip.second), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onTertiaryContainer)
        }

        // Practice progress
        AppCard {
            Text(tr("অনুশীলনের অগ্রগতি", "Practice progress"), style = MaterialTheme.typography.titleMedium)
            if (app.quizTotal == 0) {
                Text(tr("এখনও কোনো প্রশ্নের উত্তর দেওয়া হয়নি। এখনই শুরু করুন!", "You haven't answered any question yet. Start now!"), style = MaterialTheme.typography.bodyMedium)
            } else {
                val pct = app.quizCorrect * 100 / app.quizTotal
                Text(tr("${app.quizTotal}টি উত্তর • ${app.quizCorrect}টি সঠিক • সঠিকতা $pct%", "${app.quizTotal} answered • ${app.quizCorrect} correct • accuracy $pct%"), style = MaterialTheme.typography.bodyMedium)
                LinearProgressIndicator(progress = { pct / 100f }, Modifier.fillMaxWidth())
            }
            Button(onClick = { onTab("practice") }) { Text(tr("অনুশীলন করুন", "Practice now")) }
        }

        // Categories
        SectionTitle(tr("বিষয়ভিত্তিক ক্যাটাগরি", "Categories"))
        val cats = Category.values().toList()
        cats.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { c ->
                    AppCard(Modifier.weight(1f), onClick = { app.toolsFilter = c.name; onTab("tools") }) {
                        GlyphBadge(c.glyph, 40.dp)
                        Text(tr(c.bn, c.en), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text(tr("${Tools.all.count { it.cat == c }}টি টুল", "${Tools.all.count { it.cat == c }} tools"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (pair.size == 1) Box(Modifier.weight(1f)) {}
            }
        }

        // Footer credit
        Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) { DeveloperCredit() }
    }
}
