@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import android.annotation.SuppressLint
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.abusaeed.ictmaster.data.Tools

private class HtmlExample(val bn: String, val en: String, val code: String)

private val SVG_IMG = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='90' height='90'%3E%3Ccircle cx='45' cy='45' r='40' fill='%231565C0'/%3E%3Ctext x='45' y='52' font-size='20' text-anchor='middle' fill='white'%3EICT%3C/text%3E%3C/svg%3E"

private val HTML_EXAMPLES = listOf(
    HtmlExample("প্রথম ওয়েব পেজ", "First web page", """
        <!DOCTYPE html>
        <html>
        <head>
          <title>My First Page</title>
        </head>
        <body>
          <h1>Welcome to ICT</h1>
          <p>This is my first web page.</p>
        </body>
        </html>
    """.trimIndent()),
    HtmlExample("হেডিং ও প্যারাগ্রাফ", "Headings & paragraphs", """
        <h1>Heading 1</h1>
        <h2>Heading 2</h2>
        <h3>Heading 3</h3>
        <p>This is a <b>bold</b> and <i>italic</i> word.</p>
        <hr>
        <p>First line<br>Second line</p>
    """.trimIndent()),
    HtmlExample("তালিকা", "Lists", """
        <h3>Ordered list</h3>
        <ol>
          <li>Input</li>
          <li>Process</li>
          <li>Output</li>
        </ol>
        <h3>Unordered list</h3>
        <ul>
          <li>Binary</li>
          <li>Octal</li>
          <li>Hexadecimal</li>
        </ul>
    """.trimIndent()),
    HtmlExample("লিংক", "Hyperlink", """
        <p>Visit my page:</p>
        <a href="https://isaeed.netlify.app">Developer portfolio</a>
        <p>(Links are disabled in this preview.)</p>
    """.trimIndent()),
    HtmlExample("টেবিল", "Table", """
        <table border="1" cellpadding="6">
          <tr>
            <th>Decimal</th>
            <th>Binary</th>
          </tr>
          <tr>
            <td>5</td>
            <td>101</td>
          </tr>
          <tr>
            <td>10</td>
            <td>1010</td>
          </tr>
        </table>
    """.trimIndent()),
    HtmlExample("ফর্ম", "Form", """
        <form>
          <label>Name:</label><br>
          <input type="text" placeholder="Your name"><br><br>
          <input type="radio" name="g"> Male
          <input type="radio" name="g"> Female<br><br>
          <input type="submit" value="Submit">
        </form>
    """.trimIndent()),
    HtmlExample("ছবি", "Image", """
        <h3>An image</h3>
        <img src="$SVG_IMG" alt="Round logo" width="90" height="90">
        <p>Use the src attribute to give the image address.</p>
    """.trimIndent()),
    HtmlExample("CSS স্টাইল", "Styling with CSS", """
        <h1 style="color: blue; text-align: center;">Styled heading</h1>
        <p style="background-color: lightyellow; padding: 10px;">
          This paragraph has a background colour.
        </p>
    """.trimIndent())
)

private val TAGS = listOf(
    "<html>" to "ডকুমেন্টের মূল ট্যাগ|Root of the document",
    "<head>" to "শিরোনামসহ তথ্য রাখে|Holds page information",
    "<title>" to "ব্রাউজার ট্যাবের শিরোনাম|Browser tab title",
    "<body>" to "পেজের দৃশ্যমান অংশ|Visible page content",
    "<h1>…<h6>" to "হেডিং|Headings",
    "<p>" to "অনুচ্ছেদ|Paragraph",
    "<br>" to "লাইন ব্রেক|Line break",
    "<a href>" to "হাইপারলিংক|Hyperlink",
    "<img src>" to "ছবি|Image",
    "<ul> <ol> <li>" to "তালিকা|Lists",
    "<table> <tr> <td> <th>" to "টেবিল|Table",
    "<form> <input>" to "ফর্ম ও ইনপুট|Form and input"
)

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun HtmlScreen(onBack: () -> Unit) {
    var selected by rememberSaveable { mutableIntStateOf(0) }
    var code by rememberSaveable { mutableStateOf(HTML_EXAMPLES[0].code) }
    var committed by rememberSaveable { mutableStateOf(HTML_EXAMPLES[0].code) }
    val tick = rememberHaptics()

    Screen(title = tr("HTML উদাহরণ ও প্রিভিউ", "HTML Examples & Preview"), onBack = onBack, tool = Tools.byId("html")) {
        AppCard(container = MaterialTheme.colorScheme.tertiaryContainer) {
            Text(
                tr("একটি উদাহরণ বেছে নিন, কোড পরিবর্তন করুন এবং “প্রিভিউ দেখুন” চাপুন। প্রিভিউ সম্পূর্ণ অফলাইনে চলে।",
                    "Pick an example, edit the code and press “Run preview”. The preview works fully offline."),
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onTertiaryContainer
            )
        }
        ScrollChips(HTML_EXAMPLES.map { tr(it.bn, it.en) }, selected) {
            selected = it; code = HTML_EXAMPLES[it].code; committed = code; tick()
        }
        InputField(
            value = code, onChange = { code = it.take(5000) }, label = tr("HTML কোড", "HTML code"),
            keyboard = KeyboardType.Ascii, singleLine = false
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { committed = code; tick() }) { Text(tr("প্রিভিউ দেখুন", "Run preview")) }
            FilledTonalButton(onClick = { code = HTML_EXAMPLES[selected].code; committed = code; tick() }) { Text(tr("রিসেট", "Reset")) }
        }

        Text(tr("প্রিভিউ", "Preview"), style = MaterialTheme.typography.titleMedium)
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = false
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    setBackgroundColor(android.graphics.Color.WHITE)
                    webViewClient = object : WebViewClient() {
                        // keep the preview self-contained: never navigate away
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true
                    }
                }
            },
            update = { wv ->
                if (wv.tag != committed) {
                    wv.tag = committed
                    wv.loadDataWithBaseURL(null, committed, "text/html", "UTF-8", null)
                }
            },
            modifier = Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(16.dp))
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
        )

        AppCard {
            Text(tr("গুরুত্বপূর্ণ ট্যাগ", "Important tags"), style = MaterialTheme.typography.titleMedium)
            TAGS.forEach { (tag, d) ->
                val parts = d.split("|")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(tag, Modifier.weight(0.45f), fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
                    Text(tr(parts[0], parts[1]), Modifier.weight(0.55f), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
