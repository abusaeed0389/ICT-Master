@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abusaeed.ictmaster.data.Question
import com.abusaeed.ictmaster.data.Questions
import com.abusaeed.ictmaster.data.Topic

private class QuizItem(val q: Question, val order: List<Int>) {
    val correctPos: Int get() = order.indexOf(q.answer)
}

private fun makeItems(list: List<Question>) = list.map { QuizItem(it, it.options.indices.shuffled()) }

@Composable
private fun topicLabel(key: String): String = when (key) {
    "ALL" -> tr("সব বিষয়", "All topics")
    "RETRY" -> tr("ভুলগুলো আবার", "Retry wrong")
    else -> Topic.values().firstOrNull { it.name == key }?.let { tr(it.bn, it.en) } ?: key
}

@Composable
private fun diffLabel(d: Int): String = when (d) {
    1 -> tr("সহজ", "Easy")
    2 -> tr("মাঝারি", "Medium")
    3 -> tr("কঠিন", "Hard")
    else -> tr("সব স্তর", "All levels")
}

@Composable
fun PracticeScreen() {
    val app = LocalApp.current
    val tick = rememberHaptics()

    var stage by rememberSaveable { mutableIntStateOf(0) }        // 0 setup, 1 running, 2 result
    var topicIdx by rememberSaveable { mutableIntStateOf(0) }     // 0 = all
    var diff by rememberSaveable { mutableIntStateOf(0) }         // 0 = all
    var countIdx by rememberSaveable { mutableIntStateOf(1) }
    val counts = listOf(5, 10, 20)

    var items by remember { mutableStateOf<List<QuizItem>>(emptyList()) }
    var index by remember { mutableIntStateOf(0) }
    var picked by remember { mutableIntStateOf(-1) }
    var score by remember { mutableIntStateOf(0) }
    val wrong = remember { mutableStateListOf<QuizItem>() }
    var sessionKey by remember { mutableStateOf("ALL") }
    var sessionDiff by remember { mutableIntStateOf(0) }
    var confirmClear by remember { mutableStateOf(false) }

    fun start(list: List<Question>, key: String, d: Int) {
        items = makeItems(list); index = 0; picked = -1; score = 0; wrong.clear()
        sessionKey = key; sessionDiff = d; stage = 1
    }

    if (stage == 1 && items.isEmpty()) stage = 0
    BackHandler(enabled = stage == 1 || stage == 2) { stage = 0 }

    Screen(title = tr("অনুশীলন", "Practice"), tab = true) {
        when (stage) {
            0 -> {
                // ---------- setup ----------
                val topics = Topic.values().toList()
                val pool = Questions.all.filter { (topicIdx == 0 || it.topic == topics[topicIdx - 1]) && (diff == 0 || it.difficulty == diff) }

                AppCard {
                    Text(tr("আপনার অগ্রগতি", "Your progress"), style = MaterialTheme.typography.titleMedium)
                    if (app.quizTotal == 0) {
                        Text(tr("এখনও কোনো উত্তর নেই। নিচ থেকে অনুশীলন শুরু করুন।", "No answers yet. Start practising below."), style = MaterialTheme.typography.bodyMedium)
                    } else {
                        val pct = app.quizCorrect * 100 / app.quizTotal
                        Text(tr("${app.quizTotal}টি উত্তর • ${app.quizCorrect}টি সঠিক • ${app.quizTotal - app.quizCorrect}টি ভুল", "${app.quizTotal} answered • ${app.quizCorrect} correct • ${app.quizTotal - app.quizCorrect} wrong"), style = MaterialTheme.typography.bodyMedium)
                        LinearProgressIndicator(progress = { pct / 100f }, Modifier.fillMaxWidth())
                        Text(tr("সঠিকতা $pct%", "Accuracy $pct%"), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.tertiary)
                    }
                }

                SectionTitle(tr("বিষয়", "Topic"))
                ScrollChips(listOf(tr("সব বিষয় (র‍্যান্ডম)", "All topics (random)")) + topics.map { tr(it.bn, it.en) }, topicIdx) { topicIdx = it; tick() }
                SectionTitle(tr("কঠিন্যের স্তর", "Difficulty"))
                ScrollChips(listOf(diffLabel(0), diffLabel(1), diffLabel(2), diffLabel(3)), diff) { diff = it; tick() }
                SectionTitle(tr("প্রশ্ন সংখ্যা", "Number of questions"))
                ScrollChips(counts.map { "$it" }, countIdx) { countIdx = it; tick() }

                Text(tr("এই নির্বাচনে ${pool.size}টি প্রশ্ন আছে।", "${pool.size} questions match this selection."), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(
                    onClick = {
                        start(pool.shuffled().take(counts[countIdx]), if (topicIdx == 0) "ALL" else topics[topicIdx - 1].name, diff); tick()
                    },
                    enabled = pool.isNotEmpty()
                ) { Text(tr("অনুশীলন শুরু করুন", "Start practice")) }

                if (app.wrongIds.isNotEmpty()) {
                    FilledTonalButton(onClick = {
                        start(app.wrongIds.mapNotNull { Questions.byId(it) }.shuffled(), "RETRY", 0); tick()
                    }) { Text(tr("ভুল প্রশ্নগুলো আবার করুন (${app.wrongIds.size})", "Retry incorrect questions (${app.wrongIds.size})")) }
                }

                Text(
                    tr("এগুলো এই অ্যাপের জন্য লেখা মৌলিক অনুশীলনী প্রশ্ন; বোর্ডের অফিশিয়াল প্রশ্ন নয়।", "These are original practice questions written for this app; they are not official board questions."),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                SectionTitle(tr("অনুশীলনের ইতিহাস", "Practice history"))
                if (app.sessions.isEmpty()) {
                    EmptyState("✓", tr("এখনও কোনো সেশন নেই", "No sessions yet"), tr("একটি অনুশীলন শেষ করলে এখানে ফলাফল দেখা যাবে।", "Finish a practice and your result will appear here."))
                } else {
                    app.sessions.take(10).forEach { s ->
                        AppCard {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                                    Text(topicLabel(s.topic), style = MaterialTheme.typography.titleSmall)
                                    Text(formatDate(s.ts, LocalBangla.current) + " • " + diffLabel(s.difficulty), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text("${s.correct}/${s.total}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.tertiary)
                            }
                        }
                    }
                    TextButton(onClick = { confirmClear = true }) { Text(tr("অগ্রগতি রিসেট করুন", "Reset progress")) }
                }
            }

            1 -> {
                // ---------- running ----------
                val item = items[index]
                val q = item.q
                val bn = LocalBangla.current
                Text(tr("প্রশ্ন ${index + 1} / ${items.size}", "Question ${index + 1} of ${items.size}"), style = MaterialTheme.typography.labelLarge)
                LinearProgressIndicator(progress = { (index + (if (picked >= 0) 1 else 0)) / items.size.toFloat() }, Modifier.fillMaxWidth())
                Text("${tr(q.topic.bn, q.topic.en)} • ${diffLabel(q.difficulty)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(if (bn) q.qBn else q.qEn, style = MaterialTheme.typography.titleMedium)

                item.order.forEachIndexed { pos, optIdx ->
                    val isCorrect = pos == item.correctPos
                    val container = when {
                        picked < 0 -> MaterialTheme.colorScheme.surface
                        isCorrect -> MaterialTheme.colorScheme.tertiaryContainer
                        pos == picked -> MaterialTheme.colorScheme.error.copy(alpha = 0.18f)
                        else -> MaterialTheme.colorScheme.surface
                    }
                    AppCard(
                        container = container,
                        onClick = if (picked < 0) ({
                            picked = pos
                            val ok = isCorrect
                            if (ok) score++ else wrong.add(item)
                            app.recordAnswer(q.id, ok)
                            tick()
                        }) else null
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            GlyphBadge("${'A' + pos}", 34.dp)
                            Text(q.options[optIdx], Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                            if (picked >= 0 && isCorrect) Text("✓", color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
                            if (picked >= 0 && pos == picked && !isCorrect) Text("✗", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (picked >= 0) {
                    val ok = picked == item.correctPos
                    AppCard(container = if (ok) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.surfaceVariant) {
                        Text(
                            if (ok) tr("সঠিক উত্তর! 🎉", "Correct! 🎉") else tr("ভুল উত্তর। সঠিক উত্তর: ${'A' + item.correctPos}", "Incorrect. Correct answer: ${'A' + item.correctPos}"),
                            style = MaterialTheme.typography.titleSmall,
                            color = if (ok) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.error
                        )
                        Text(if (bn) q.expBn else q.expEn, style = MaterialTheme.typography.bodyMedium)
                    }
                    Button(onClick = {
                        if (index + 1 < items.size) { index++; picked = -1 }
                        else { app.addSession(sessionKey, sessionDiff, items.size, score); stage = 2 }
                        tick()
                    }) { Text(if (index + 1 < items.size) tr("পরের প্রশ্ন", "Next question") else tr("ফলাফল দেখুন", "See result")) }
                }
            }

            else -> {
                // ---------- result ----------
                val total = items.size
                val pct = if (total == 0) 0 else score * 100 / total
                val bn = LocalBangla.current
                AppCard(container = MaterialTheme.colorScheme.primaryContainer) {
                    Text(tr("আপনার স্কোর", "Your score"), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("$score / $total  ($pct%)", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text(
                        when {
                            pct >= 80 -> tr("চমৎকার! দারুণ করেছেন।", "Excellent work!")
                            pct >= 50 -> tr("ভালো হয়েছে! আরেকটু অনুশীলন করলে আরও ভালো হবে।", "Good job! A little more practice will make it better.")
                            else -> tr("চালিয়ে যান! ভুলগুলো আবার অনুশীলন করুন।", "Keep going! Practise the incorrect ones again.")
                        },
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { stage = 0; tick() }) { Text(tr("নতুন অনুশীলন", "New practice")) }
                    if (wrong.isNotEmpty()) OutlinedButton(onClick = { start(wrong.map { it.q }, "RETRY", 0); tick() }) {
                        Text(tr("ভুলগুলো আবার (${wrong.size})", "Retry wrong (${wrong.size})"))
                    }
                }
                if (wrong.isNotEmpty()) {
                    SectionTitle(tr("যেগুলো ভুল হয়েছে", "Questions you missed"))
                    wrong.forEach { w ->
                        AppCard {
                            Text(if (bn) w.q.qBn else w.q.qEn, style = MaterialTheme.typography.titleSmall)
                            Text(tr("সঠিক উত্তর: ", "Correct answer: ") + w.q.options[w.q.answer], style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.tertiary)
                            Text(if (bn) w.q.expBn else w.q.expEn, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(tr("অগ্রগতি রিসেট করবেন?", "Reset progress?")) },
            text = { Text(tr("অনুশীলনের সব উত্তর, ভুলের তালিকা ও ইতিহাস মুছে যাবে।", "All answers, the incorrect list and practice history will be erased.")) },
            confirmButton = { TextButton(onClick = { app.clearQuizProgress(); confirmClear = false }) { Text(tr("রিসেট", "Reset")) } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text(tr("বাতিল", "Cancel")) } }
        )
    }
}
