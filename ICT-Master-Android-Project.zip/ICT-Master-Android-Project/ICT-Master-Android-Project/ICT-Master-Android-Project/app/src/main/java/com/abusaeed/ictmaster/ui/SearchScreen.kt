@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.abusaeed.ictmaster.data.Tools

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(onBack: () -> Unit, onOpenTool: (String) -> Unit) {
    val app = LocalApp.current
    var query by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (e: Exception) { } }

    Screen(title = tr("খুঁজুন", "Search"), onBack = onBack) {
        InputField(
            value = query, onChange = { query = it.take(60) },
            label = tr("টুল বা বিষয়ের নাম লিখুন", "Type a tool or topic name"),
            keyboard = KeyboardType.Text, mono = false,
            modifier = Modifier.focusRequester(focus)
        )
        val results = Tools.search(query)
        if (query.isBlank()) {
            if (app.recentSearches.isNotEmpty()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle(tr("সাম্প্রতিক খোঁজ", "Recent searches"), Modifier.weight(1f))
                    TextButton(onClick = { app.clearSearches() }) { Text(tr("মুছুন", "Clear")) }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    app.recentSearches.forEach { s -> AssistChip(onClick = { query = s }, label = { Text(s) }) }
                }
            }
            SectionTitle(tr("পরামর্শ", "Suggestions"))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tools.suggestions.forEach { s -> AssistChip(onClick = { query = s }, label = { Text(s) }) }
            }
        } else if (results.isEmpty()) {
            EmptyState("?", tr("কিছু পাওয়া যায়নি", "Nothing found"), tr("অন্য কোনো শব্দ দিয়ে খুঁজে দেখুন।", "Try a different keyword."))
        } else {
            results.forEach { t ->
                ToolRow(t, app.favorites.contains(t.id), { app.toggleFavorite(t.id) }) {
                    app.addSearch(query); onOpenTool(t.id)
                }
            }
        }
    }
}
