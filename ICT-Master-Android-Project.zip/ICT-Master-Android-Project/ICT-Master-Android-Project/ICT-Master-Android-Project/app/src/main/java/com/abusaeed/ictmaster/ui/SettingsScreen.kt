@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(onAbout: () -> Unit) {
    val app = LocalApp.current
    val tick = rememberHaptics()
    var confirmHistory by remember { mutableStateOf(false) }
    var confirmQuiz by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(false) }
    var nameDraft by remember { mutableStateOf("") }

    Screen(title = tr("সেটিংস", "Settings"), tab = true) {
        AppCard {
            Text(tr("থিম", "Theme"), style = MaterialTheme.typography.titleMedium)
            ScrollChips(listOf(tr("সিস্টেম ডিফল্ট", "System default"), tr("লাইট মোড", "Light mode"), tr("ডার্ক মোড", "Dark mode")), app.theme) { app.theme = it; tick() }
        }

        AppCard {
            Text(tr("ভাষা", "Language"), style = MaterialTheme.typography.titleMedium)
            ScrollChips(listOf("বাংলা", "English"), if (app.isBangla) 0 else 1) { app.lang = if (it == 0) "bn" else "en"; tick() }
            Text(tr("ভাষা পরিবর্তন করলে পুরো অ্যাপের ইন্টারফেস বদলে যাবে।", "Changing the language updates the entire interface."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        AppCard {
            Text(tr("পছন্দসমূহ", "Preferences"), style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("হ্যাপটিক ফিডব্যাক", "Haptic feedback"), style = MaterialTheme.typography.bodyLarge)
                    Text(tr("বাটনে চাপ দিলে হালকা কম্পন", "A light vibration on taps"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = app.haptic, onCheckedChange = { app.haptic = it })
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("আপনার নাম", "Your name"), style = MaterialTheme.typography.bodyLarge)
                    Text(if (app.userName.isBlank()) tr("হোম স্ক্রিনে শুভেচ্ছার জন্য", "Used for the greeting on Home") else app.userName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledTonalButton(onClick = { nameDraft = app.userName; editName = true }) { Text(tr("পরিবর্তন", "Edit")) }
            }
        }

        AppCard {
            Text(tr("ডেটা", "Data"), style = MaterialTheme.typography.titleMedium)
            Text(tr("সব ডেটা শুধু আপনার ফোনেই থাকে।", "All data stays on your phone."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { confirmHistory = true }) { Text(tr("ইতিহাস মুছুন", "Clear history")) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { confirmQuiz = true }) { Text(tr("অনুশীলনের অগ্রগতি রিসেট", "Reset practice progress")) }
            }
        }

        AppCard {
            Text(tr("প্রাইভেসি তথ্য", "Privacy information"), style = MaterialTheme.typography.titleMedium)
            Text(
                tr(
                    "ICT Master কোনো ব্যক্তিগত তথ্য সংগ্রহ করে না। কোনো অ্যাকাউন্ট, বিজ্ঞাপন, অ্যানালিটিক্স বা বিশেষ পারমিশন নেই। আপনার ইতিহাস ও সেটিংস শুধু এই ডিভাইসে সংরক্ষিত থাকে। ডেভেলপারের লিংকে চাপ দিলেই কেবল ব্রাউজার ইন্টারনেট ব্যবহার করে।",
                    "ICT Master collects no personal data. There are no accounts, ads, analytics or special permissions. Your history and settings are stored only on this device. The internet is used by your browser only when you open the developer link."
                ),
                style = MaterialTheme.typography.bodyMedium
            )
        }

        AppCard(onClick = onAbout) {
            Text(tr("অ্যাপ সম্পর্কে", "About application"), style = MaterialTheme.typography.titleMedium)
            Text(tr("ICT Master • সংস্করণ $APP_VERSION", "ICT Master • Version $APP_VERSION"), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        AppCard {
            Text(tr("ডেভেলপার", "Developer"), style = MaterialTheme.typography.titleMedium)
            Text(tr("নাম: $DEV_NAME", "Name: $DEV_NAME"), style = MaterialTheme.typography.bodyMedium)
            DeveloperCredit()
        }
    }

    if (confirmHistory) ConfirmDialog(
        tr("সব ইতিহাস মুছবেন?", "Clear all history?"), tr("এই কাজটি ফিরিয়ে নেওয়া যাবে না।", "This cannot be undone."),
        onYes = { app.clearHistory(); confirmHistory = false }, onNo = { confirmHistory = false }
    )
    if (confirmQuiz) ConfirmDialog(
        tr("অগ্রগতি রিসেট করবেন?", "Reset progress?"), tr("অনুশীলনের সব উত্তর ও ইতিহাস মুছে যাবে।", "All practice answers and history will be erased."),
        onYes = { app.clearQuizProgress(); confirmQuiz = false }, onNo = { confirmQuiz = false }
    )
    if (editName) {
        AlertDialog(
            onDismissRequest = { editName = false },
            title = { Text(tr("আপনার নাম", "Your name")) },
            text = { OutlinedTextField(value = nameDraft, onValueChange = { nameDraft = it.take(30) }, singleLine = true, label = { Text(tr("নাম", "Name")) }) },
            confirmButton = { TextButton(onClick = { app.userName = nameDraft; editName = false }) { Text(tr("সংরক্ষণ", "Save")) } },
            dismissButton = { TextButton(onClick = { editName = false }) { Text(tr("বাতিল", "Cancel")) } }
        )
    }
}

@Composable
private fun ConfirmDialog(title: String, text: String, onYes: () -> Unit, onNo: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo,
        title = { Text(title) }, text = { Text(text) },
        confirmButton = { TextButton(onClick = onYes) { Text(tr("হ্যাঁ", "Yes")) } },
        dismissButton = { TextButton(onClick = onNo) { Text(tr("বাতিল", "Cancel")) } }
    )
}
