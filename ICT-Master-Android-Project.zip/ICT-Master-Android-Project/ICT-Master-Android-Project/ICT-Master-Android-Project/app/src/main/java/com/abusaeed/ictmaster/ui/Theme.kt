@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abusaeed.ictmaster.ui

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.abusaeed.ictmaster.data.AppState

val Navy = Color(0xFF0A1F44)
val Blue = Color(0xFF1565C0)
val Cyan = Color(0xFF00B8D9)

private val LightColors = lightColorScheme(
    primary = Color(0xFF1558B0), onPrimary = Color.White,
    primaryContainer = Color(0xFFD8E6FF), onPrimaryContainer = Color(0xFF001B3F),
    secondary = Color(0xFF0A2A5E), onSecondary = Color.White,
    secondaryContainer = Color(0xFFDCE7F7), onSecondaryContainer = Color(0xFF0A1F44),
    tertiary = Color(0xFF00708F), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFC4F0FF), onTertiaryContainer = Color(0xFF001F2A),
    background = Color(0xFFF4F7FD), onBackground = Color(0xFF0E1726),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF0E1726),
    surfaceVariant = Color(0xFFE6ECF7), onSurfaceVariant = Color(0xFF45506A),
    outline = Color(0xFF7A869F), outlineVariant = Color(0xFFD0D9E9),
    error = Color(0xFFB3261E), onError = Color.White
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9CC2FF), onPrimary = Color(0xFF00315F),
    primaryContainer = Color(0xFF0F3A75), onPrimaryContainer = Color(0xFFD8E6FF),
    secondary = Color(0xFFB9C9E8), onSecondary = Color(0xFF0A1F44),
    secondaryContainer = Color(0xFF22324F), onSecondaryContainer = Color(0xFFDCE7F7),
    tertiary = Color(0xFF4FD8F2), onTertiary = Color(0xFF00363F),
    tertiaryContainer = Color(0xFF004E5C), onTertiaryContainer = Color(0xFFC4F0FF),
    background = Color(0xFF0A1220), onBackground = Color(0xFFE4EAF6),
    surface = Color(0xFF0F182A), onSurface = Color(0xFFE4EAF6),
    surfaceVariant = Color(0xFF1A2640), onSurfaceVariant = Color(0xFFB4BED3),
    outline = Color(0xFF8590A8), outlineVariant = Color(0xFF2C3A57),
    error = Color(0xFFFFB4AB), onError = Color(0xFF690005)
)

private val base = Typography()
// Generous line heights keep Bangla matras (vowel signs) from being clipped.
private val AppTypography = Typography(
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.Bold, lineHeight = 38.sp),
    headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.Bold, lineHeight = 34.sp),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold, lineHeight = 32.sp),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold, lineHeight = 28.sp),
    titleSmall = base.titleSmall.copy(lineHeight = 24.sp),
    bodyLarge = base.bodyLarge.copy(lineHeight = 28.sp),
    bodyMedium = base.bodyMedium.copy(lineHeight = 24.sp),
    bodySmall = base.bodySmall.copy(lineHeight = 20.sp),
    labelLarge = base.labelLarge.copy(lineHeight = 22.sp),
    labelMedium = base.labelMedium.copy(lineHeight = 20.sp)
)

val LocalApp = staticCompositionLocalOf<AppState> { error("AppState not provided") }
val LocalBangla = compositionLocalOf { true }

/** Returns the Bangla or English text depending on the language chosen in Settings. */
@Composable
@ReadOnlyComposable
fun tr(bn: String, en: String): String = if (LocalBangla.current) bn else en

@Composable
fun ICTMasterTheme(app: AppState, content: @Composable () -> Unit) {
    val dark = when (app.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val c = WindowCompat.getInsetsController(window, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    CompositionLocalProvider(LocalApp provides app, LocalBangla provides app.isBangla) {
        MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, typography = AppTypography, content = content)
    }
}
