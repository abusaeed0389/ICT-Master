
@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class
)

package com.abusaeed.ictmaster.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

import com.abusaeed.ictmaster.data.Category
import com.abusaeed.ictmaster.data.Tools

@Composable
fun ToolsScreen(onOpenTool: (String) -> Unit) {
    val app = LocalApp.current
    var query by rememberSaveable { mutableStateOf("") }
    val cats = Category.values().toList()

    // filter index: 0 all, 1 favorites, 2.. categories
    val requested = app.toolsFilter
    var filter by rememberSaveable { mutableStateOf(0) }

    LaunchedEffect(requested) {
        if (requested != null) {
            filter = if (requested == "FAV") 1
            else 2 + cats.indexOfFirst { it.name == requested }.coerceAtLeast(0)

            app.toolsFilter = null
        }
    }

    Screen(title = tr("টুলস", "Tools"), tab = true) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it.take(60) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = {
                Text(
                    tr(
                        "টুল খুঁজুন (বাংলা বা English)",
                        "Search tools (Bangla or English)"
                    )
                )
            },
            leadingIcon = {
                Icon(Icons.Filled.Search, contentDescription = null)
            },
            shape = RoundedCornerShape(16.dp)
        )

        ScrollChips(
            listOf(
                tr("সব", "All"),
                tr("প্রিয়", "Favorites")
            ) + cats.map { tr(it.bn, it.en) },
            filter
        ) {
            filter = it
        }

        var list = if (query.isBlank()) {
            Tools.all
        } else {
            Tools.search(query)
        }

        if (filter == 1) {
            list = list.filter {
                app.favorites.contains(it.id)
            }
        } else if (filter >= 2) {
            list = list.filter {
                it.cat == cats[filter - 2]
            }
        }

        if (list.isEmpty()) {
            if (filter == 1 && query.isBlank()) {
                EmptyState(
                    "♡",
                    tr("কোনো প্রিয় টুল নেই", "No favorite tools yet"),
                    tr(
                        "টুলের পাশের ♡ আইকনে চাপ দিয়ে প্রিয় তালিকায় যোগ করুন।",
                        "Tap the heart icon on a tool to add it here."
                    )
                )
            } else {
                EmptyState(
                    "?",
                    tr("কিছু পাওয়া যায়নি", "Nothing found"),
                    tr(
                        "অন্য কোনো শব্দ দিয়ে খুঁজে দেখুন।",
                        "Try a different keyword."
                    )
                )
            }
        } else {
            list.forEach { t ->
                ToolRow(
                    t,
                    app.favorites.contains(t.id),
                    { app.toggleFavorite(t.id) }
                ) {
                    onOpenTool(t.id)
                }
            }
        }
    }
}
